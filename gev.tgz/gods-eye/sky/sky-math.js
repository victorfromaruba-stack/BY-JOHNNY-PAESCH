// The Sky panel's math: what's up tonight, Space Station passes, and planes crossing the Moon or
// Sun, seen from the telescope's spot. No page code here, so the same file runs in the browser
// (window.SkyMath, before sky.js) and in Node for tests (require). It needs two libraries,
// passed in: astronomy-engine (`Astronomy`) and satellite.js (`satellite`), both MIT.
(function (root) {
  'use strict';
  const RAD = Math.PI / 180, DEG = 180 / Math.PI;
  const WGS_A = 6378137, WGS_E2 = 6.69437999014e-3, EARTH_KM = 6371;

  const COMPASS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const compass = (az) => COMPASS[Math.round((((az % 360) + 360) % 360) / 22.5) % 16];

  /** Earth-fixed metres for a latitude/longitude (degrees) and height (metres). */
  function ecef(lat, lon, h) {
    const p = lat * RAD, l = lon * RAD, s = Math.sin(p);
    const n = WGS_A / Math.sqrt(1 - WGS_E2 * s * s);
    return [(n + h) * Math.cos(p) * Math.cos(l), (n + h) * Math.cos(p) * Math.sin(l), (n * (1 - WGS_E2) + h) * s];
  }

  /** Azimuth/elevation (degrees) and distance (m) of a point seen from the observer. */
  function lookFrom(obs, target) {
    const o = ecef(obs.lat, obs.lon, obs.h || 0);
    const d = [target[0] - o[0], target[1] - o[1], target[2] - o[2]];
    const p = obs.lat * RAD, l = obs.lon * RAD;
    const e = -Math.sin(l) * d[0] + Math.cos(l) * d[1];
    const n = -Math.sin(p) * Math.cos(l) * d[0] - Math.sin(p) * Math.sin(l) * d[1] + Math.cos(p) * d[2];
    const u = Math.cos(p) * Math.cos(l) * d[0] + Math.cos(p) * Math.sin(l) * d[1] + Math.sin(p) * d[2];
    const range = Math.hypot(e, n, u);
    return { az: (Math.atan2(e, n) * DEG + 360) % 360, el: Math.asin(u / range) * DEG, range };
  }

  /** A point at azimuth/elevation and distance (m) from the observer, Earth-fixed metres. */
  function pointToward(obs, az, el, dist) {
    const o = ecef(obs.lat, obs.lon, obs.h || 0);
    const p = obs.lat * RAD, l = obs.lon * RAD, A = az * RAD, E = el * RAD;
    const e = Math.cos(E) * Math.sin(A), n = Math.cos(E) * Math.cos(A), u = Math.sin(E);
    return [
      o[0] + dist * (-Math.sin(l) * e - Math.sin(p) * Math.cos(l) * n + Math.cos(p) * Math.cos(l) * u),
      o[1] + dist * (Math.cos(l) * e - Math.sin(p) * Math.sin(l) * n + Math.cos(p) * Math.sin(l) * u),
      o[2] + dist * (Math.cos(p) * n + Math.sin(p) * u),
    ];
  }

  /** Angle in degrees between two sky directions given as az/el in degrees. */
  function separation(a, b) {
    const c = Math.sin(a.el * RAD) * Math.sin(b.el * RAD) + Math.cos(a.el * RAD) * Math.cos(b.el * RAD) * Math.cos((a.az - b.az) * RAD);
    return Math.acos(Math.min(1, Math.max(-1, c))) * DEG;
  }

  /** Where a plane is `dt` seconds after its report: straight on, steady speed and climb. */
  function moveAlong(lat, lon, trackDeg, metres) {
    const d = metres / (EARTH_KM * 1000), t = trackDeg * RAD, p1 = lat * RAD, l1 = lon * RAD;
    const p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(t));
    const l2 = l1 + Math.atan2(Math.sin(t) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2));
    return [p2 * DEG, ((l2 * DEG + 540) % 360) - 180];
  }

  function make(Astronomy, satellite) {
    const observer = (spot) => new Astronomy.Observer(spot.lat, spot.lon, spot.h || 0);

    /** Az/el (degrees, refraction included) and distance of the Sun, Moon or a planet. */
    function bodyAt(name, spot, date) {
      const obs = observer(spot);
      const eq = Astronomy.Equator(Astronomy.Body[name], date, obs, true, true);
      const hor = Astronomy.Horizon(date, obs, eq.ra, eq.dec, 'normal');
      return { az: hor.azimuth, el: hor.altitude, au: eq.dist };
    }

    /** Apparent radius in degrees (Sun, Moon). */
    function radiusDeg(name, au) {
      const km = name === 'Moon' ? 1737.4 : 695700;
      return Math.asin(km / (au * 149597870.7)) * DEG;
    }

    function riseSet(name, spot, from, dir) {
      const t = Astronomy.SearchRiseSet(Astronomy.Body[name], observer(spot), dir, from, 1.5);
      return t ? t.date : null;
    }

    function sunBelow(spot, from, deg, dir) {
      const t = Astronomy.SearchAltitude(Astronomy.Body.Sun, observer(spot), dir, from, 1.5, deg);
      return t ? t.date : null;
    }

    /**
     * Tonight at the spot: darkness window, the Moon, and which planets are up while it's dark.
     * `now` defaults to the current time; "tonight" is the next sunset, or this night if dark.
     */
    function tonight(spot, now = new Date()) {
      const sunNow = bodyAt('Sun', spot, now);
      const dayStart = new Date(now.getTime() - (sunNow.el < -0.833 ? 14 : 0) * 3600_000);
      const sunset = riseSet('Sun', spot, dayStart, -1);
      const dark = sunBelow(spot, sunset, -18, -1);
      const dawnDark = sunBelow(spot, dark || sunset, -18, +1);
      const sunrise = riseSet('Sun', spot, sunset, +1);
      const moon = bodyAt('Moon', spot, now);
      const illum = Astronomy.Illumination(Astronomy.Body.Moon, now);
      const phaseAngle = Astronomy.MoonPhase(now);
      const phaseName = phaseAngle < 22.5 ? 'New Moon' : phaseAngle < 67.5 ? 'Waxing crescent' : phaseAngle < 112.5 ? 'First quarter'
        : phaseAngle < 157.5 ? 'Waxing gibbous' : phaseAngle < 202.5 ? 'Full Moon' : phaseAngle < 247.5 ? 'Waning gibbous'
          : phaseAngle < 292.5 ? 'Last quarter' : phaseAngle < 337.5 ? 'Waning crescent' : 'New Moon';
      const nightFrom = dark || sunset, nightTo = dawnDark || sunrise;
      const samples = [];
      for (let t = nightFrom.getTime(); t <= nightTo.getTime(); t += 30 * 60_000) samples.push(new Date(t));
      const planets = ['Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'].map((name) => {
        let best = null;
        // Evening twilight counts for the inner planets, which never stray far from the Sun.
        const from = name === 'Mercury' || name === 'Venus' ? [sunset, ...samples] : samples;
        for (const t of from) {
          const b = bodyAt(name, spot, t);
          if (b.el > 10 && (!best || b.el > best.el)) best = { ...b, at: t };
        }
        if (!best) return null;
        const mag = Astronomy.Illumination(Astronomy.Body[name], best.at).mag;
        return { name, bestAt: best.at, el: Math.round(best.el), az: Math.round(best.az), dir: compass(best.az), mag: Math.round(mag * 10) / 10 };
      }).filter(Boolean);
      return {
        sunset, dark, dawnDark, sunrise,
        sun: sunNow,
        moon: { ...moon, dir: compass(moon.az), lit: Math.round(illum.phase_fraction * 100), phase: phaseName,
          rise: riseSet('Moon', spot, now, +1), set: riseSet('Moon', spot, now, -1) },
        planets,
      };
    }

    // ---- satellites -------------------------------------------------------------------------
    /** Parses CelesTrak's three-line TLE text into [{name, id, satrec}]. */
    function parseTle(text) {
      const lines = String(text).split(/\r?\n/).map((l) => l.trimEnd()).filter(Boolean);
      const out = [];
      for (let i = 0; i + 2 < lines.length + 0; i++) {
        if (lines[i + 1]?.startsWith('1 ') && lines[i + 2]?.startsWith('2 ') && !lines[i].startsWith('1 ') && !lines[i].startsWith('2 ')) {
          try {
            const satrec = satellite.twoline2satrec(lines[i + 1], lines[i + 2]);
            out.push({ name: lines[i].trim(), id: Number(lines[i + 1].slice(2, 7)), satrec });
          } catch { /* skip a bad set */ }
          i += 2;
        }
      }
      return out;
    }

    function satLook(sat, spot, date) {
      const pv = satellite.propagate(sat.satrec, date);
      if (!pv || !pv.position || typeof pv.position === 'boolean') return null;
      const gmst = satellite.gstime(date);
      const ecf = satellite.eciToEcf(pv.position, gmst);
      const la = satellite.ecfToLookAngles({ latitude: spot.lat * RAD, longitude: spot.lon * RAD, height: (spot.h || 0) / 1000 }, ecf);
      return { az: (la.azimuth * DEG + 360) % 360, el: la.elevation * DEG, km: la.rangeSat, eci: pv.position, ecf };
    }

    /** True when the satellite (ECI km) is in sunlight: a cylindrical Earth shadow is enough here. */
    function sunlit(eci, date) {
      const s = Astronomy.GeoVector(Astronomy.Body.Sun, date, true);
      const n = Math.hypot(s.x, s.y, s.z), u = [s.x / n, s.y / n, s.z / n];
      const dot = eci.x * u[0] + eci.y * u[1] + eci.z * u[2];
      if (dot > 0) return true;
      const perp = Math.hypot(eci.x - dot * u[0], eci.y - dot * u[1], eci.z - dot * u[2]);
      return perp > 6378;
    }

    /**
     * Passes of one satellite over the spot from `start` for `hours`: rise, highest point, set,
     * and whether it can be seen by eye (the sky dark enough and the satellite in sunlight).
     */
    function passes(sat, spot, start = new Date(), hours = 48, minEl = 10) {
      const step = 20_000, end = start.getTime() + hours * 3600_000;
      const sunCache = new Map();
      const sunEl = (t) => {
        const k = Math.floor(t / 300_000);
        if (!sunCache.has(k)) sunCache.set(k, bodyAt('Sun', spot, new Date(k * 300_000)).el);
        return sunCache.get(k);
      };
      const out = [];
      let prev = satLook(sat, spot, start), cur = null;
      const edge = (t0, t1, rising) => { // bisect the horizon crossing to one second
        let a = t0, b = t1;
        while (b - a > 1000) {
          const m = (a + b) / 2, l = satLook(sat, spot, new Date(m));
          if (l && (l.el > 0) === rising) b = m; else a = m;
        }
        return new Date(b);
      };
      if (prev && prev.el > 0) cur = { rise: start, riseAz: prev.az, max: prev, maxAt: start, visible: false };
      for (let t = start.getTime() + step; t <= end; t += step) {
        const l = satLook(sat, spot, new Date(t));
        if (!l || !prev) { prev = l; continue; }
        if (!cur && prev.el <= 0 && l.el > 0) {
          const rise = edge(t - step, t, true);
          cur = { rise, riseAz: satLook(sat, spot, rise).az, max: l, maxAt: new Date(t), visible: false };
        }
        if (cur) {
          if (l.el > cur.max.el) { cur.max = l; cur.maxAt = new Date(t); }
          if (l.el > minEl && sunEl(t) < -6 && sunlit(l.eci, new Date(t))) cur.visible = true;
          if (l.el <= 0) {
            const set = edge(t - step, t, false);
            if (cur.max.el >= minEl) {
              out.push({
                name: sat.name, id: sat.id, rise: cur.rise, set, maxAt: cur.maxAt, maxEl: Math.round(cur.max.el),
                from: compass(cur.riseAz), to: compass(satLook(sat, spot, set).az), maxDir: compass(cur.max.az),
                minutes: Math.max(1, Math.round((set - cur.rise) / 60_000)), visible: cur.visible,
              });
            }
            cur = null;
          }
        }
        prev = l;
      }
      return out;
    }

    // ---- planes in front of the Moon or Sun ---------------------------------------------------
    /**
     * For each plane, its closest approach to the Moon/Sun as seen from the spot over the next
     * `horizon` seconds, assuming it flies straight on. A crossing is `sep < radius`; anything
     * under ~0.7° is inside the Seestar's view.
     */
    function transits(planes, spot, body, now = new Date(), horizon = 300) {
      // Where the Moon/Sun is every 20 s; in between it moves in a straight line well enough.
      const knots = [];
      for (let s = 0; s <= horizon + 20; s += 20) knots.push(bodyAt(body, spot, new Date(now.getTime() + s * 1000)));
      const b0 = knots[0];
      if (Math.max(b0.el, knots[knots.length - 1].el) < 3) return { body, up: false, el: b0.el, list: [] };
      const radius = radiusDeg(body, b0.au);
      const skyAt = (s) => {
        const i = Math.min(knots.length - 2, Math.floor(s / 20)), f = (s - i * 20) / 20, a = knots[i], b = knots[i + 1];
        let daz = b.az - a.az; if (daz > 180) daz -= 360; if (daz < -180) daz += 360;
        return { az: a.az + daz * f, el: a.el + (b.el - a.el) * f };
      };
      const list = [];
      for (const p of planes) {
        if (![p.lat, p.lon, p.alt, p.gs, p.trk].every(Number.isFinite) || p.gs < 30) continue;
        const age = Math.max(0, now.getTime() / 1000 - (p.t || now.getTime() / 1000));
        if (age > 90) continue; // too old to extrapolate
        const at = (s) => {
          const dt = age + s;
          const [la, lo] = moveAlong(p.lat, p.lon, p.trk, p.gs * dt);
          const look = lookFrom(spot, ecef(la, lo, Math.max(0, p.alt + (p.vr || 0) * dt)));
          return look.el < 0 ? null : { sep: separation(look, skyAt(s)), at: s, el: look.el, km: look.range / 1000 };
        };
        let best = { sep: 999, at: 0, el: 0, km: 0 };
        for (let s = 0; s <= horizon; s += 1) { const c = at(s); if (c && c.sep < best.sep) best = c; }
        // A plane near the telescope sweeps a degree or more across the sky each second, so look
        // again around the closest second in fine steps, or a crossing slips between two samples.
        if (best.sep < 5) {
          const from = Math.max(0, best.at - 1), to = Math.min(horizon, best.at + 1);
          for (let s = from; s <= to; s += 0.02) { const c = at(s); if (c && c.sep < best.sep) best = c; }
        }
        best.at = Math.round(best.at);
        if (best.sep < 3) {
          list.push({ id: p.id, call: p.call || p.id, inSec: best.at, sep: Math.round(best.sep * 100) / 100,
            crosses: best.sep < radius, inView: best.sep < 0.7, km: Math.round(best.km * 10) / 10, altM: Math.round(p.alt) });
        }
      }
      list.sort((a, b) => a.sep - b.sep || a.inSec - b.inSec);
      return { body, up: b0.el > 3, el: b0.el, az: b0.az, dir: compass(b0.az), radius, list };
    }

    return { bodyAt, radiusDeg, tonight, parseTle, satLook, sunlit, passes, transits };
  }

  const SkyMath = { make, ecef, lookFrom, pointToward, separation, moveAlong, compass };
  if (typeof module !== 'undefined' && module.exports) module.exports = SkyMath;
  else root.SkyMath = SkyMath;
})(typeof globalThis !== 'undefined' ? globalThis : this);
