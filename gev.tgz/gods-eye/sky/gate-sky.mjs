// The door's sky data, for the Sky panel in God's Eye View (gods-eye/sky/sky.js). Members only;
// gate.mjs calls handleSky() after checking the member's cookie.
//
//   GET  /sky/spot     where the telescope is set up (default: Aruba), and whether you may move it
//   POST /sky/spot     {lat, lon, name?}: move it. Only the owner (GEV_OWNER_MEMBER), kept in
//                      GEV_SKY_SPOT_FILE so it survives restarts
//   GET  /sky/planes   aircraft within ~110 km of the spot, from OpenSky (a small area costs one
//                      OpenSky credit; uses OPENSKY_CLIENT_ID/SECRET when set). Fetched only while
//                      someone asks, at most every 15 s, shared by everyone watching
//   GET  /sky/weather  cloud cover for the next two nights at the spot (Open-Meteo, no key), 30 min
//
// Plain Node, no dependencies. Every upstream call has a timeout and keeps serving the last good
// answer when the upstream fails.
import { readFileSync, writeFileSync, renameSync } from 'node:fs';

const OWNERS = new Set((process.env.GEV_OWNER_MEMBER || '').split(',').map((s) => s.trim()).filter(Boolean));
const SPOT_FILE = process.env.GEV_SKY_SPOT_FILE || '';
const DEFAULT_SPOT = { lat: 12.52, lon: -69.97, name: 'Aruba', at: null, set: false };
const PLANES_EVERY_MS = 15_000;
const PLANES_BOX_DEG = 1.0; // ± around the spot: about 110 km, one OpenSky credit
const WEATHER_EVERY_MS = 30 * 60_000;

let spot = DEFAULT_SPOT;
try {
  if (SPOT_FILE) {
    const s = JSON.parse(readFileSync(SPOT_FILE, 'utf8'));
    if (validLatLon(s.lat, s.lon)) spot = { ...DEFAULT_SPOT, ...s, set: true };
  }
} catch { /* not set yet */ }

function validLatLon(lat, lon) {
  return Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;
}

function json(res, status, body, maxAge = 0) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': maxAge ? `private, max-age=${maxAge}` : 'no-store' });
  res.end(JSON.stringify(body));
}

function readBody(req, limit = 2048) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too big')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

async function fetchJson(url, init = {}, ms = 12_000) {
  const r = await fetch(url, { ...init, signal: AbortSignal.timeout(ms) });
  if (!r.ok) { const e = new Error(`HTTP ${r.status}`); e.status = r.status; e.retryAfter = Number(r.headers.get('retry-after')); throw e; }
  return r.json();
}

// ---- OpenSky ----------------------------------------------------------------------------------
let token = { value: '', until: 0 };
async function openskyToken() {
  const id = process.env.OPENSKY_CLIENT_ID, secret = process.env.OPENSKY_CLIENT_SECRET;
  if (!id || !secret) return '';
  if (token.value && Date.now() < token.until) return token.value;
  const body = new URLSearchParams({ grant_type: 'client_credentials', client_id: id, client_secret: secret });
  const t = await fetchJson('https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token',
    { method: 'POST', body, headers: { 'content-type': 'application/x-www-form-urlencoded' } });
  token = { value: t.access_token || '', until: Date.now() + Math.max(60, (t.expires_in || 1800) - 120) * 1000 };
  return token.value;
}

let planes = { at: 0, key: '', body: null, cooldownUntil: 0, inflight: null };
async function nearbyPlanes() {
  const key = `${spot.lat.toFixed(3)},${spot.lon.toFixed(3)}`;
  const now = Date.now();
  const fresh = planes.body && planes.key === key && now - planes.at < PLANES_EVERY_MS;
  if (fresh || (planes.body && planes.key === key && now < planes.cooldownUntil)) return planes.body;
  if (planes.inflight) return planes.inflight;
  planes.inflight = (async () => {
    const b = PLANES_BOX_DEG;
    const q = new URLSearchParams({ lamin: spot.lat - b, lamax: spot.lat + b, lomin: spot.lon - b * 1.2, lomax: spot.lon + b * 1.2, extended: '1' });
    try {
      let auth = '';
      try { auth = await openskyToken(); } catch { /* fall back to anonymous */ }
      const d = await fetchJson(`https://opensky-network.org/api/states/all?${q}`, auth ? { headers: { authorization: `Bearer ${auth}` } } : {});
      // OpenSky state vector: [icao24, callsign, country, time_position, last_contact, lon, lat,
      //   baro_altitude, on_ground, velocity, true_track, vertical_rate, sensors, geo_altitude, ...]
      const list = (d.states || []).filter((s) => Number.isFinite(s[5]) && Number.isFinite(s[6]) && !s[8]).map((s) => ({
        id: s[0], call: String(s[1] || '').trim(), lon: s[5], lat: s[6],
        alt: Number.isFinite(s[13]) ? s[13] : s[7], gs: s[9], trk: s[10], vr: s[11] || 0,
        t: s[3] || s[4] || d.time,
      }));
      planes = { ...planes, at: Date.now(), key, body: { at: Date.now(), source: 'OpenSky Network', planes: list } };
    } catch (e) {
      const wait = e.status === 429 ? Math.min(Math.max(e.retryAfter || 300, 60), 3600) * 1000 : 60_000;
      planes.cooldownUntil = Date.now() + wait;
      if (!planes.body || planes.key !== key) planes = { ...planes, key, body: { at: 0, source: 'OpenSky Network', planes: [], unavailable: true } };
    } finally {
      planes.inflight = null;
    }
    return planes.body;
  })();
  return planes.inflight;
}

// ---- Open-Meteo -------------------------------------------------------------------------------
let weather = { at: 0, key: '', body: null };
async function cloudForecast() {
  const key = `${spot.lat.toFixed(2)},${spot.lon.toFixed(2)}`;
  if (weather.body && weather.key === key && Date.now() - weather.at < WEATHER_EVERY_MS) return weather.body;
  const q = new URLSearchParams({
    latitude: spot.lat, longitude: spot.lon, timezone: 'auto', forecast_days: '3',
    hourly: 'cloud_cover,cloud_cover_low,cloud_cover_mid,cloud_cover_high,precipitation_probability,visibility,wind_speed_10m',
    daily: 'sunrise,sunset',
  });
  try {
    const d = await fetchJson(`https://api.open-meteo.com/v1/forecast?${q}`);
    weather = { at: Date.now(), key, body: { at: Date.now(), source: 'Open-Meteo', ...d } };
  } catch {
    if (!weather.body || weather.key !== key) return { unavailable: true, source: 'Open-Meteo' };
  }
  return weather.body;
}

/** Handles /sky/*. Returns true when it answered. `member` is the verified cookie's body. */
export function handleSky(req, res, url, member) {
  if (!url.pathname.startsWith('/sky/')) return false;
  const owner = OWNERS.has(member?.m);
  if (url.pathname === '/sky/spot' && req.method === 'GET') {
    json(res, 200, { ...spot, owner });
    return true;
  }
  if (url.pathname === '/sky/spot' && req.method === 'POST') {
    if (!owner) { json(res, 403, { error: 'Only the owner moves the telescope.' }); return true; }
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) { json(res, 415, { error: 'JSON only' }); return true; }
    readBody(req).then((raw) => {
      const b = JSON.parse(raw);
      const lat = Number(b.lat), lon = Number(b.lon);
      if (!validLatLon(lat, lon)) return json(res, 400, { error: 'bad position' });
      const name = String(b.name || '').replace(/[^\p{L}\p{N} .,'’-]/gu, '').slice(0, 40) || 'Telescope';
      spot = { lat: Math.round(lat * 1e5) / 1e5, lon: Math.round(lon * 1e5) / 1e5, name, at: new Date().toISOString(), set: true };
      if (SPOT_FILE) {
        try { writeFileSync(`${SPOT_FILE}.tmp`, JSON.stringify(spot)); renameSync(`${SPOT_FILE}.tmp`, SPOT_FILE); } catch { /* kept in memory */ }
      }
      json(res, 200, { ...spot, owner });
    }).catch(() => json(res, 400, { error: 'bad request' }));
    return true;
  }
  if (req.method !== 'GET') { json(res, 405, { error: 'GET only' }); return true; }
  if (url.pathname === '/sky/planes') {
    nearbyPlanes().then((b) => json(res, 200, b)).catch(() => json(res, 200, { planes: [], unavailable: true }));
    return true;
  }
  if (url.pathname === '/sky/weather') {
    cloudForecast().then((b) => json(res, 200, b, 600)).catch(() => json(res, 200, { unavailable: true }));
    return true;
  }
  json(res, 404, { error: 'not found' });
  return true;
}
