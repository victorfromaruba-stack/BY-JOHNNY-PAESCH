// Sky panel for God's Eye View: what the owner's telescope can see tonight, and when.
//   Tonight       clouds while it's dark, the Moon, which planets are up
//   Space Station passes of the ISS, China's station and Hubble over the telescope's spot,
//                 and the next one you can see with your own eyes
//   Planes × Moon planes about to fly in front of the Moon (or Sun) as seen from the spot
//   Telescope     the live view, the spot on the globe, and (owner only) moving the spot
// On the globe: a 🔭 marker at the spot, a pointer toward the Moon, a line to the Space Station
// while it passes, and the live view in a small window. Alerts slide in for everyone watching.
//
// Data: the door's /sky/* (spot, planes from OpenSky, clouds from Open-Meteo), the app's own
// /api/celestrak (satellite orbits) and /scope/status. Math: sky-math.js with astronomy-engine
// and satellite.js, loaded before this. Installed by scripts/install-gods-eye.sh as /gev-sky/.
(() => {
  if (!window.SkyMath || !window.Astronomy || !window.satellite) return;
  const SM = window.SkyMath, M = SM.make(window.Astronomy, window.satellite);
  const $ = (h) => { const t = document.createElement('template'); t.innerHTML = h.trim(); return t.content.firstElementChild; };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const get = async (u) => { const r = await fetch(u, { cache: 'no-store', credentials: 'same-origin' }); if (!r.ok) throw new Error(r.status); return r; };

  const S = {
    spot: { lat: 12.52, lon: -69.97, name: 'Aruba', set: false, owner: false },
    tz: 'America/Aruba', open: false, tab: 'tonight',
    weather: null, night: null, sats: [], passes: [], nextVisible: undefined, bright: null,
    planes: null, transit: { Moon: null, Sun: null }, live: { on: false }, dismissed: new Set(), pipClosed: false,
  };

  // ---- time --------------------------------------------------------------------------------
  const fmt = (d, o) => d ? new Intl.DateTimeFormat('en-US', { timeZone: S.tz, ...o }).format(d) : '—';
  const hm = (d) => fmt(d, { hour: 'numeric', minute: '2-digit' });
  const dayHm = (d) => {
    const same = fmt(d, { day: 'numeric' }) === fmt(new Date(), { day: 'numeric' });
    const tomorrow = fmt(d, { day: 'numeric' }) === fmt(new Date(Date.now() + 864e5), { day: 'numeric' });
    return `${same ? 'Today' : tomorrow ? 'Tomorrow' : fmt(d, { weekday: 'short', month: 'short', day: 'numeric' })} ${hm(d)}`;
  };
  const inWords = (sec) => sec < 60 ? `${Math.max(0, Math.round(sec))} s` : sec < 3600 ? `${Math.round(sec / 60)} min` : `${Math.floor(sec / 3600)} h ${Math.round((sec % 3600) / 60)} min`;

  // ---- page parts ----------------------------------------------------------------------------
  const btn = $('<button id="gev-sky-btn" type="button" aria-expanded="false" aria-controls="gev-sky" aria-label="Sky panel">🌌<span>Sky</span></button>');
  const panel = $(`<aside id="gev-sky" aria-label="Sky over the telescope" aria-hidden="true">
    <header><h2 class="gev-sky-mono">🌌 Sky over <span id="gev-sky-where">Aruba</span></h2><button class="x" type="button" aria-label="Close">✕</button></header>
    <nav role="tablist">
      <button role="tab" data-tab="tonight">Tonight</button><button role="tab" data-tab="passes">Station</button>
      <button role="tab" data-tab="planes">Planes</button><button role="tab" data-tab="scope">Telescope</button>
    </nav><div class="body" role="tabpanel"></div></aside>`);
  const alertEl = $('<div id="gev-sky-alert" role="alert"><p></p><button type="button" aria-label="Dismiss">✕</button></div>');
  const pip = $('<div id="gev-sky-pip"><video muted playsinline autoplay></video><span class="live">Live telescope</span><a href="/scope" aria-label="Watch the telescope full screen"></a><button type="button" aria-label="Hide the small telescope window">✕</button></div>');
  const body = panel.querySelector('.body');

  btn.addEventListener('click', () => setOpen(!S.open));
  panel.querySelector('.x').addEventListener('click', () => setOpen(false));
  panel.querySelector('nav').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) { S.tab = b.dataset.tab; body.scrollTop = 0; render(); tick(); } });
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && S.open) setOpen(false); });
  alertEl.querySelector('button').addEventListener('click', () => { if (alertEl.dataset.id) S.dismissed.add(alertEl.dataset.id); alertEl.classList.remove('on'); });
  alertEl.querySelector('p').addEventListener('click', () => { S.tab = alertEl.dataset.tab || S.tab; body.scrollTop = 0; setOpen(true); });
  pip.querySelector('button').addEventListener('click', (e) => { e.preventDefault(); S.pipClosed = true; stopPip(); });

  function setOpen(open) {
    S.open = open;
    panel.classList.toggle('open', open);
    panel.setAttribute('aria-hidden', String(!open));
    btn.setAttribute('aria-expanded', String(open));
    if (open) { render(); tick(); }
  }

  // ---- data ----------------------------------------------------------------------------------
  async function loadSpot() {
    try { S.spot = await (await get('/sky/spot')).json(); } catch { /* keep the default */ }
    panel.querySelector('#gev-sky-where').textContent = S.spot.name || 'the telescope';
  }
  async function loadWeather() {
    try {
      const w = await (await get('/sky/weather')).json();
      if (!w.unavailable) { S.weather = w; if (w.timezone) S.tz = w.timezone; }
    } catch { /* shown as unavailable */ }
  }
  function computeNight() { try { S.night = M.tonight(S.spot, new Date()); } catch { S.night = null; } }

  const MAIN_SATS = { 25544: 'Space Station (ISS)', 48274: 'China’s Tiangong station', 20580: 'Hubble Space Telescope' };
  async function loadSats() {
    const groups = await Promise.all(['stations', 'visual'].map((g) => get(`/api/celestrak/${g}`).then((r) => r.text()).catch(() => '')));
    const all = groups.flatMap((t) => M.parseTle(t));
    const seen = new Set();
    S.sats = all.filter((s) => !seen.has(s.id) && seen.add(s.id));
    computePasses();
  }
  function computePasses() {
    const main = S.sats.filter((s) => MAIN_SATS[s.id]);
    const now = new Date(Date.now() - 15 * 60_000); // include a pass that's happening right now
    S.passes = main.flatMap((s) => M.passes(s, S.spot, now, 48, 10).map((p) => ({ ...p, name: MAIN_SATS[s.id] })))
      .filter((p) => p.set > Date.now()).sort((a, b) => a.rise - b.rise);
    S.nextVisible = undefined; S.bright = null;
  }
  // The next ISS pass you can see by eye can be weeks away; look up to 30 days ahead, a day at a time.
  function findNextVisible() {
    if (S.nextVisible !== undefined) return;
    const iss = S.sats.find((s) => s.id === 25544); if (!iss) return;
    S.nextVisible = null;
    let day = 0;
    const step = () => {
      const from = new Date(Date.now() + day * 864e5);
      const hit = M.passes(iss, S.spot, from, 24, 10).find((p) => p.visible && p.set > Date.now());
      if (hit) { S.nextVisible = { ...hit, name: MAIN_SATS[25544] }; render(); return; }
      if (++day < 30) setTimeout(step, 0); else { S.nextVisible = false; render(); }
    };
    step();
  }
  // Other bright satellites you can see tonight (the ~150 brightest), worked out in small chunks.
  function findBright() {
    if (S.bright) return;
    S.bright = [];
    const list = S.sats.filter((s) => !MAIN_SATS[s.id]);
    let i = 0;
    const chunk = () => {
      const end = Math.min(list.length, i + 8);
      for (; i < end; i++) {
        for (const p of M.passes(list[i], S.spot, new Date(), 12, 30)) if (p.visible) S.bright.push(p);
      }
      if (i < list.length) setTimeout(chunk, 0);
      else { S.bright.sort((a, b) => a.rise - b.rise); if (S.tab === 'passes') render(); }
    };
    chunk();
  }

  async function loadPlanes() {
    try { S.planes = await (await get('/sky/planes')).json(); } catch { S.planes = { planes: [], unavailable: true }; }
    for (const b of ['Moon', 'Sun']) S.transit[b] = M.transits(S.planes.planes || [], S.spot, b, new Date(), 300);
  }

  let hls = null;
  async function loadLive() {
    try { S.live = await (await get('/scope/status')).json(); } catch { S.live = { on: false }; }
    if (S.live.on && !S.pipClosed) startPip(); else stopPip();
  }
  async function startPip() {
    const v = pip.querySelector('video'), src = `/${S.live.src}/index.m3u8`;
    if (pip.classList.contains('on') && pip.dataset.src === src) return;
    stopPip(); pip.dataset.src = src; pip.classList.add('on');
    if (v.canPlayType('application/vnd.apple.mpegurl')) { v.src = src; v.play().catch(() => {}); return; }
    try {
      if (!window.Hls) await new Promise((ok, no) => { const s = document.createElement('script'); s.src = `/${S.live.src}/hls.min.js`; s.onload = ok; s.onerror = no; document.head.append(s); });
      if (!window.Hls?.isSupported()) return stopPip();
      hls = new window.Hls({ lowLatencyMode: true }); hls.on(window.Hls.Events.ERROR, (_e, d) => { if (d.fatal) stopPip(); });
      hls.loadSource(src); hls.attachMedia(v); v.play().catch(() => {});
    } catch { stopPip(); }
  }
  function stopPip() {
    if (hls) { hls.destroy(); hls = null; }
    const v = pip.querySelector('video'); v.removeAttribute('src'); v.load();
    pip.classList.remove('on'); delete pip.dataset.src;
  }

  // ---- the globe -----------------------------------------------------------------------------
  const ICON = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><circle cx="24" cy="24" r="22" fill="#05101a" stroke="#5fe3ff" stroke-width="2"/><text x="24" y="32" font-size="24" text-anchor="middle">🔭</text></svg>');
  function globe() {
    const g = window.__godsEyeView, C = window.Cesium;
    if (!g?.viewer || !C) return;
    const ents = g.viewer.entities, s = S.spot, now = new Date();
    const at = C.Cartesian3.fromDegrees(s.lon, s.lat, 0);
    const put = (id, spec) => { const old = ents.getById(id); if (old) ents.remove(old); if (spec) ents.add({ id, ...spec }); };
    put('gev-sky-spot', {
      position: at,
      billboard: { image: ICON, width: 40, height: 40, verticalOrigin: C.VerticalOrigin.BOTTOM, heightReference: C.HeightReference.CLAMP_TO_GROUND, disableDepthTestDistance: Number.POSITIVE_INFINITY },
      label: { text: `Telescope · ${s.name || ''}`, font: '600 13px system-ui, sans-serif', fillColor: C.Color.fromCssColorString('#e6ebee'), outlineColor: C.Color.BLACK, outlineWidth: 3,
        style: C.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new C.Cartesian2(0, -46), verticalOrigin: C.VerticalOrigin.BOTTOM, heightReference: C.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY, distanceDisplayCondition: new C.DistanceDisplayCondition(0, 3.0e6) },
    });
    // A pointer toward the Moon, 40 km long: easy to see once you zoom in on the spot.
    const moon = M.bodyAt('Moon', s, now);
    put('gev-sky-moon', moon.el > 0 ? {
      polyline: { positions: [C.Cartesian3.fromDegrees(s.lon, s.lat, 30), new C.Cartesian3(...SM.pointToward(s, moon.az, moon.el, 40_000))], width: 6,
        arcType: C.ArcType.NONE, material: new C.PolylineGlowMaterialProperty({ glowPower: 0.3, color: C.Color.fromCssColorString('#f4f1de') }),
        depthFailMaterial: new C.PolylineGlowMaterialProperty({ glowPower: 0.3, color: C.Color.fromCssColorString('#f4f1de').withAlpha(0.6) }) },
      position: new C.Cartesian3(...SM.pointToward(s, moon.az, moon.el, 40_000)),
      label: { text: `🌕 Moon ${Math.round(moon.el)}° ${SM.compass(moon.az)}`, font: '600 13px system-ui, sans-serif', fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK,
        outlineWidth: 3, style: C.LabelStyle.FILL_AND_OUTLINE, distanceDisplayCondition: new C.DistanceDisplayCondition(0, 1.5e6) },
    } : null);
    // While a station passes overhead: a line from the telescope to where it really is.
    const live = S.passes.find((p) => p.rise <= now && p.set >= now);
    const sat = live && S.sats.find((x) => x.id === live.id);
    const look = sat && M.satLook(sat, s, now);
    put('gev-sky-sat', look && look.el > 0 ? {
      polyline: { positions: [C.Cartesian3.fromDegrees(s.lon, s.lat, 30), new C.Cartesian3(look.ecf.x * 1000, look.ecf.y * 1000, look.ecf.z * 1000)], width: 2,
        arcType: C.ArcType.NONE, material: new C.PolylineDashMaterialProperty({ color: C.Color.fromCssColorString('#5fe3ff') }) },
      position: new C.Cartesian3(look.ecf.x * 1000, look.ecf.y * 1000, look.ecf.z * 1000),
      point: { pixelSize: 10, color: C.Color.fromCssColorString('#5fe3ff'), outlineColor: C.Color.WHITE, outlineWidth: 2 },
      label: { text: `🛰 ${live.name}`, font: '600 13px system-ui, sans-serif', fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 3,
        style: C.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new C.Cartesian2(0, -20) },
    } : null);
    g.requestRender?.();
  }
  function flyToSpot(tries = 0) {
    if (window.matchMedia('(max-width: 600px)').matches) setOpen(false);
    const g = window.__godsEyeView, C = window.Cesium;
    if (!g?.viewer || !C) { if (tries < 20) setTimeout(() => flyToSpot(tries + 1), 500); return; }
    // Stand behind the telescope and look the way it points: toward the Moon when it's up, so the
    // pointer rises from the 🔭 into the sky; otherwise north.
    const moon = M.bodyAt('Moon', S.spot, new Date()), az = moon.el > 0 ? moon.az : 0;
    const [lat, lon] = SM.moveAlong(S.spot.lat, S.spot.lon, (az + 180) % 360, 14_000);
    g.viewer.camera.flyTo({ destination: C.Cartesian3.fromDegrees(lon, lat, 4500),
      orientation: { heading: C.Math.toRadians(az), pitch: C.Math.toRadians(-14), roll: 0 }, duration: 3 });
  }

  // ---- alerts --------------------------------------------------------------------------------
  function alerts() {
    const now = Date.now(), cands = [];
    for (const b of ['Moon', 'Sun']) {
      const t = S.transit[b]; if (!t?.up) continue;
      for (const p of t.list) {
        if (!p.inView || p.inSec > 180) continue;
        const what = p.crosses ? `crossing the ${b}` : `passing right by the ${b}`;
        cands.push({ id: `tr-${b}-${p.id}`, tab: 'planes', hot: p.crosses, rank: p.crosses ? 0 : 2,
          html: `<b>✈️ ${b === 'Moon' ? '🌕' : '☀️'} Plane ${what} in ${inWords(p.inSec)}</b>${esc(p.call)} · aim at the ${b} (${t.dir}, ${Math.round(t.el)}° up)${b === 'Sun' ? ' · solar filter on!' : ''}` });
      }
    }
    for (const p of S.passes) {
      const until = (p.rise - now) / 1000;
      if (p.rise <= now && p.set >= now) cands.push({ id: `sat-${p.id}-${+p.rise}`, tab: 'passes', rank: 1,
        html: `<b>🛰 ${esc(p.name)} is over the telescope now</b>highest ${p.maxEl}° in the ${p.maxDir} · until ${hm(p.set)}${p.visible ? ' · look up, you can see it!' : ''}` });
      else if (until > 0 && until < 180 && (p.visible || p.maxEl >= 30)) cands.push({ id: `sat-${p.id}-${+p.rise}`, tab: 'passes', rank: 1,
        html: `<b>🛰 ${esc(p.name)} passes over in ${inWords(until)}</b>rises ${p.from}, ${p.maxEl}° high in the ${p.maxDir}${p.visible ? ' · visible by eye' : ''}` });
    }
    const a = cands.filter((c) => !S.dismissed.has(c.id)).sort((x, y) => x.rank - y.rank)[0];
    if (!a) { alertEl.classList.remove('on'); return; }
    alertEl.dataset.id = a.id; alertEl.dataset.tab = a.tab;
    alertEl.querySelector('p').innerHTML = a.html;
    alertEl.classList.toggle('hot', !!a.hot);
    alertEl.classList.add('on');
  }

  // ---- the panel -----------------------------------------------------------------------------
  function render() {
    panel.querySelectorAll('nav [data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === S.tab)));
    if (!S.open) return;
    body.innerHTML = { tonight: tonightHtml, passes: passesHtml, planes: planesHtml, scope: scopeHtml }[S.tab]();
    body.querySelector('[data-fly]')?.addEventListener('click', () => flyToSpot());
    body.querySelector('[data-here]')?.addEventListener('click', setSpotHere);
    if (S.tab === 'passes') { findNextVisible(); findBright(); }
  }

  function tonightHtml() {
    const n = S.night; if (!n) return '<div class="card">Working out tonight’s sky…</div>';
    const from = n.sunset, to = n.sunrise;
    const w = S.weather?.hourly, hours = [];
    if (w) for (let i = 0; i < w.time.length; i++) {
      const t = new Date(`${w.time[i]}:00${offsetOf(S.weather)}`);
      if (t >= new Date(from.getTime() - 3600_000) && t <= to) hours.push({ t, c: w.cloud_cover[i], rain: w.precipitation_probability?.[i] });
    }
    const darkHours = hours.filter((h) => h.t >= (n.dark || from) && h.t <= (n.dawnDark || to));
    const cloud = darkHours.length ? Math.round(darkHours.reduce((s, h) => s + h.c, 0) / darkHours.length) : null;
    const moonBright = n.moon.lit > 70 && (n.moon.el > 0 || (n.moon.rise && n.moon.rise < to));
    const rating = cloud == null ? ['Clouds unknown', 'dim'] : cloud < 30 ? ['Good night for the telescope', 'good'] : cloud < 60 ? ['So-so: some clouds', 'warn'] : ['Cloudy: probably not tonight', 'bad'];
    const bars = hours.map((h) => `<i title="${hm(h.t)}: ${h.c}% clouds" style="height:${Math.max(4, h.c)}%;opacity:${0.35 + h.c / 160}"></i>`).join('');
    const ticks = hours.filter((_, i) => i % 3 === 0).map((h) => `<span>${fmt(h.t, { hour: 'numeric' })}</span>`).join('');
    const targets = [
      n.moon.lit > 5 && (n.moon.el > 10 || (n.moon.rise && n.moon.rise < to)) ? `the Moon (${n.moon.lit}% lit)` : null,
      ...n.planets.filter((p) => ['Jupiter', 'Saturn', 'Mars', 'Venus'].includes(p.name)).map((p) => p.name),
    ].filter(Boolean);
    return `
      <div class="card"><h3 class="gev-sky-mono">Tonight</h3>
        <div class="big ${rating[1]}">${rating[0]}</div>
        <div class="dim">${cloud == null ? 'No cloud forecast right now.' : `About ${cloud}% cloud while it’s dark.`}${moonBright ? ' Bright Moon: great for the Moon, harder for faint galaxies.' : ''}</div>
        ${hours.length ? `<div class="clouds" aria-label="Cloud cover by hour">${bars}</div><div class="clouds-x">${ticks}</div>` : ''}
        ${targets.length ? `<div class="note">Best targets: ${targets.slice(0, 3).join(', ')}.</div>` : ''}
      </div>
      <div class="card"><h3 class="gev-sky-mono">Darkness</h3>
        <div class="row"><span>Sunset</span><b>${hm(n.sunset)}</b></div>
        <div class="row"><span>Fully dark</span><b>${n.dark ? `${hm(n.dark)} – ${hm(n.dawnDark)}` : '—'}</b></div>
        <div class="row"><span>Sunrise</span><b>${hm(n.sunrise)}</b></div>
      </div>
      <div class="card"><h3 class="gev-sky-mono">The Moon</h3>
        <div class="row"><span>${esc(n.moon.phase)}</span><b>${n.moon.lit}% lit</b></div>
        <div class="row"><span>Now</span><b>${n.moon.el > 0 ? `${Math.round(n.moon.el)}° up in the ${n.moon.dir}` : 'below the horizon'}</b></div>
        <div class="row"><span>${n.moon.el > 0 ? 'Sets' : 'Rises'}</span><b>${dayHm(n.moon.el > 0 ? n.moon.set : n.moon.rise)}</b></div>
      </div>
      <div class="card"><h3 class="gev-sky-mono">Planets up tonight</h3>
        ${n.planets.length ? n.planets.map((p) => `<div class="row"><span><b>${p.name}</b> <span class="dim">${p.mag < 0 ? 'very bright' : p.mag < 1.5 ? 'bright' : 'faint'}</span></span><span>best ${hm(p.bestAt)} · ${p.el}° ${p.dir}</span></div>`).join('') : '<div class="dim">No bright planets well up tonight.</div>'}
      </div>
      <div class="note">Clouds: Open-Meteo. Sky positions worked out here for the telescope’s spot.</div>`;
  }

  function offsetOf(w) {
    const s = Number(w?.utc_offset_seconds || 0), sign = s < 0 ? '-' : '+', a = Math.abs(s);
    return `${sign}${String(Math.floor(a / 3600)).padStart(2, '0')}:${String(Math.floor((a % 3600) / 60)).padStart(2, '0')}`;
  }

  function passRow(p) {
    const now = Date.now(), live = p.rise <= now && p.set >= now;
    return `<div class="row"><span><b>${esc(p.name)}</b><br><span class="dim">${live ? 'Overhead now' : dayHm(p.rise)} · rises ${p.from}, ${p.maxEl}° high in the ${p.maxDir}, sets ${p.to} · ${p.minutes} min</span></span>
      <span>${p.visible ? '<span class="tag eye">See it by eye</span>' : '<span class="tag no">Not visible</span>'}</span></div>`;
  }
  function passesHtml() {
    if (!S.sats.length) return '<div class="card">Loading satellite orbits…</div>';
    const nv = S.nextVisible;
    return `
      <div class="card"><h3 class="gev-sky-mono">Next time you can see the Space Station</h3>
        ${nv === undefined || nv === null ? '<div class="dim">Looking up to 30 days ahead…</div>' : nv === false ? '<div class="dim">Not in the next 30 days from this spot.</div>'
          : `<div class="big">${dayHm(nv.rise)}</div><div class="dim">Rises in the ${nv.from}, climbs to ${nv.maxEl}° in the ${nv.maxDir}, sets in the ${nv.to}. About ${nv.minutes} minutes, no telescope needed.</div>`}
      </div>
      <div class="card"><h3 class="gev-sky-mono">Passes over the telescope · next 2 days</h3>
        ${S.passes.length ? S.passes.slice(0, 12).map(passRow).join('') : '<div class="dim">None high enough in the next 2 days.</div>'}
        <div class="note">“Not visible” passes happen in daylight or while the station is in Earth’s shadow. The globe draws a line to it while it passes.</div>
      </div>
      <div class="card"><h3 class="gev-sky-mono">Other bright satellites tonight</h3>
        ${!S.bright ? '<div class="dim">Working it out…</div>' : S.bright.length ? S.bright.slice(0, 8).map(passRow).join('') : '<div class="dim">None high and sunlit in the next 12 hours.</div>'}
      </div>
      <div class="note">Orbits: CelesTrak, through God’s Eye View.</div>`;
  }

  function planesHtml() {
    const rows = (b) => {
      const t = S.transit[b];
      if (!t) return '<div class="dim">Checking…</div>';
      if (!t.up) return `<div class="dim">The ${b} is ${t.el < 0 ? 'below the horizon' : 'too low'} right now.</div>`;
      const head = `<div class="row"><span>The ${b} is</span><b>${Math.round(t.el)}° up in the ${t.dir}</b></div>`;
      if (!t.list.length) return `${head}<div class="dim">No plane heading near it in the next 5 minutes.</div>`;
      return head + t.list.slice(0, 6).map((p) => `<div class="row"><span><b>${esc(p.call)}</b><br><span class="dim">${p.km} km away · ${Math.round(p.altM * 3.281 / 100) * 100} ft · ${p.sep}° from centre</span></span>
        <span>${p.crosses ? '<span class="tag hot">Crosses</span>' : p.inView ? '<span class="tag view">In view</span>' : '<span class="tag no">Close</span>'}<br><b>in ${inWords(p.inSec)}</b></span></div>`).join('');
    };
    const n = S.planes?.planes?.length;
    return `
      <div class="card"><h3 class="gev-sky-mono">🌕 Planes in front of the Moon</h3>${rows('Moon')}</div>
      <div class="card"><h3 class="gev-sky-mono">☀️ Planes in front of the Sun</h3>${rows('Sun')}
        <div class="note warn">The Sun only with the Seestar’s solar filter on. Never look at it without one.</div></div>
      <div class="note">${S.planes?.unavailable ? 'Flight data is unavailable right now; trying again shortly.' : `${n ?? '…'} planes near the telescope right now.`}
        Point at the Moon and start recording about 10 seconds early: a crossing lasts under a second.
        Predictions assume planes fly straight on, and work best within a minute or two. “In view” means it should pass through the Seestar’s view.
        Flight data: OpenSky Network.</div>`;
  }

  function scopeHtml() {
    const s = S.spot;
    return `
      <div class="card"><h3 class="gev-sky-mono">Live view</h3>
        ${S.live.on ? `<div class="big good">● Streaming now</div><div class="act"><a href="/scope">Watch full screen</a>${S.pipClosed ? '<button type="button" data-pip>Show the small window</button>' : ''}</div>`
          : '<div class="dim">The telescope isn’t streaming right now. When it is, a small live window shows on the globe.</div>'}
      </div>
      <div class="card"><h3 class="gev-sky-mono">Where it’s set up</h3>
        <div class="row"><span>${esc(s.name)}</span><b>${s.lat.toFixed(4)}, ${s.lon.toFixed(4)}</b></div>
        <div class="dim">${s.set ? `Set ${s.at ? dayHm(new Date(s.at)) : ''}.` : 'Not set yet: using the middle of Aruba.'} Everything in this panel is worked out for this spot.</div>
        <div class="act"><button type="button" data-fly>Fly to the telescope</button></div>
      </div>
      ${s.owner ? `<div class="card"><h3 class="gev-sky-mono">Move the telescope (only you see this)</h3>
        <div class="dim">At your observing spot, tap below. Your phone asks to share its location once.</div>
        <input id="gev-sky-name" maxlength="40" placeholder="Name this spot, e.g. Alto Vista" value="${esc(s.set ? s.name : '')}">
        <div class="act"><button type="button" data-here>📍 Set the spot to where I am</button></div><div class="note" id="gev-sky-msg"></div></div>` : ''}`;
  }

  function setSpotHere() {
    const msg = body.querySelector('#gev-sky-msg');
    if (!navigator.geolocation) { msg.textContent = 'This browser can’t share its location.'; return; }
    msg.textContent = 'Getting your location…';
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const name = body.querySelector('#gev-sky-name')?.value || 'Telescope';
      try {
        const r = await fetch('/sky/spot', { method: 'POST', headers: { 'content-type': 'application/json' }, credentials: 'same-origin',
          body: JSON.stringify({ lat: pos.coords.latitude, lon: pos.coords.longitude, name }) });
        if (!r.ok) throw new Error((await r.json()).error || r.status);
        S.spot = await r.json();
        panel.querySelector('#gev-sky-where').textContent = S.spot.name;
        computeNight(); computePasses(); await loadWeather(); globe(); render();
      } catch (e) { msg.textContent = `Couldn’t save it: ${e.message}`; }
    }, (e) => { msg.textContent = e.code === 1 ? 'Location is blocked for this site. Allow it in your browser settings, then try again.' : 'Couldn’t get your location. Try again outside.'; },
    { enableHighAccuracy: true, timeout: 20000 });
  }
  body.addEventListener('click', (e) => { if (e.target.closest('[data-pip]')) { S.pipClosed = false; loadLive(); render(); } });

  // ---- the clock -----------------------------------------------------------------------------
  let lastPlanes = 0, lastLive = 0, lastNight = 0, lastSats = 0, lastSpot = 0, busy = false;
  async function tick() {
    if (busy) return;
    busy = true;
    try { await step(); } finally { busy = false; }
  }
  async function step() {
    const now = Date.now();
    if (now - lastSpot > 5 * 60_000) { lastSpot = now; await loadSpot(); }
    if (now - lastNight > 10 * 60_000) { lastNight = now; computeNight(); loadWeather().then(() => S.tab === 'tonight' && render()); }
    if (now - lastSats > 30 * 60_000) { lastSats = now; loadSats().then(() => { globe(); render(); }); }
    if (now - lastLive > 30_000) { lastLive = now; await loadLive(); }
    // Planes cost OpenSky credits: only while someone is looking at them or the telescope is live.
    const moonUp = S.night?.moon?.el > 3 || M.bodyAt('Moon', S.spot, new Date()).el > 3, sunUp = M.bodyAt('Sun', S.spot, new Date()).el > 3;
    const wantPlanes = (S.open && S.tab === 'planes') || (S.live.on && (moonUp || sunUp));
    if (wantPlanes && now - lastPlanes > 15_000) { lastPlanes = now; await loadPlanes(); }
    else if (S.planes) for (const b of ['Moon', 'Sun']) S.transit[b] = M.transits(S.planes.planes || [], S.spot, b, new Date(), 300);
    globe(); alerts();
    if (S.open && S.tab !== 'scope') render();
  }

  function start() {
    document.body.append(btn, panel, alertEl, pip);
    tick(); setInterval(tick, 5000);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start, { once: true });
})();
