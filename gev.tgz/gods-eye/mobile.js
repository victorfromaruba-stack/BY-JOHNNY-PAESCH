// Phone mode for God's Eye View: marks narrow screens with html.gev-phone (mobile.css does the
// rest) and adds two thumb buttons, Layers and Views, that open the app's own left and right
// panel stacks as a bottom sheet. Nothing in the app is moved or rewritten; computers never see
// any of it. Installed by scripts/install-gods-eye.sh next to the built app.
(() => {
  const root = document.documentElement;
  const phone = matchMedia('(max-width: 600px), (max-height: 500px) and (pointer: coarse)');
  const SHEETS = { layers: 'gev-sheet-layers', views: 'gev-sheet-views' };

  const icon = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const LAYERS = icon('<path d="M12 3 2 8l10 5 10-5-10-5Z"/><path d="m2 13 10 5 10-5"/>');
  const VIEWS = icon('<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>');

  let bar, scrim, open = null;

  function setSheet(name) {
    open = open === name ? null : name;
    for (const [key, cls] of Object.entries(SHEETS)) root.classList.toggle(cls, open === key);
    bar?.querySelectorAll('button').forEach((b) => b.setAttribute('aria-expanded', String(b.dataset.sheet === open)));
  }

  function build() {
    if (bar) return;
    bar = document.createElement('div');
    bar.id = 'gev-phone-bar';
    bar.innerHTML = `<button type="button" data-sheet="layers" aria-expanded="false" aria-controls="left-panel-stack">${LAYERS}<span>Layers</span></button>
      <button type="button" data-sheet="views" aria-expanded="false" aria-controls="right-context-rail">${VIEWS}<span>Views</span></button>`;
    bar.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-sheet]');
      if (b) setSheet(b.dataset.sheet);
    });
    scrim = document.createElement('div');
    scrim.id = 'gev-sheet-scrim';
    scrim.addEventListener('click', () => { open && setSheet(open); });
    document.body.append(scrim, bar);
    addEventListener('keydown', (e) => { if (e.key === 'Escape' && open) setSheet(open); });
  }

  function apply() {
    root.classList.toggle('gev-phone', phone.matches);
    if (phone.matches) build();
    else if (open) setSheet(open);
  }

  phone.addEventListener?.('change', apply);
  if (document.body) apply();
  else document.addEventListener('DOMContentLoaded', apply, { once: true });
})();
