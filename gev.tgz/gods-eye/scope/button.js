// A "Live telescope" button on God's Eye View, shown only while the telescope's home box answers
// (the door's /scope/status). It opens /scope, the door's viewer page. Nothing in the app is
// changed. Installed by scripts/install-gods-eye.sh next to the built app, as /gev-scope.js.
(() => {
  const CSS = `
#gev-scope-btn { position: fixed; z-index: 30; top: 96px; right: 52px; display: inline-flex; align-items: center; gap: 8px;
  min-height: 44px; padding: 0 16px; border: 1px solid rgba(95, 227, 255, .35); border-radius: 22px;
  background: rgba(5, 10, 16, .72); color: #e6ebee; text-decoration: none; backdrop-filter: blur(8px);
  font: 600 12px/1 ui-monospace, "SF Mono", Menlo, Consolas, monospace; letter-spacing: .14em; text-transform: uppercase; }
#gev-scope-btn:hover, #gev-scope-btn:focus-visible { border-color: #5fe3ff; outline: none; }
#gev-scope-btn i { width: 8px; height: 8px; border-radius: 50%; background: #ff4d4d; box-shadow: 0 0 8px #ff4d4d; }
html.gev-phone #gev-scope-btn { top: auto; right: 12px; bottom: calc(env(safe-area-inset-bottom) + 148px); padding: 0 14px; }
html.gev-phone #gev-scope-btn span { display: none; }
`;
  async function check() {
    let on = false;
    try { on = (await (await fetch('/scope/status', { cache: 'no-store' })).json()).on === true; } catch { /* door without a telescope */ }
    let btn = document.getElementById('gev-scope-btn');
    if (on && !btn) {
      const style = document.createElement('style');
      style.textContent = CSS;
      btn = document.createElement('a');
      btn.id = 'gev-scope-btn';
      btn.href = '/scope';
      btn.setAttribute('aria-label', 'Live telescope');
      btn.innerHTML = '<i aria-hidden="true"></i>🔭<span>Live telescope</span>';
      document.head.append(style);
      document.body.append(btn);
    } else if (!on && btn) {
      btn.remove();
    }
  }
  const go = () => { check(); setInterval(check, 60000); };
  if (document.body) go();
  else document.addEventListener('DOMContentLoaded', go, { once: true });
})();
