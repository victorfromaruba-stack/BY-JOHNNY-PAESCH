// The door in front of God's Eye View. Tailscale Funnel puts it on the public
// internet; this lets in only browsers that came from the Inner Hotel Circle.
//
//   1. A signed-in, active Insider taps "Open" in the Circle. The Circle's
//      gev-pass function (BY-JOHNNY-PAESCH: circle/supabase/functions/gev-pass)
//      signs a pass good for two minutes and one use, and sends the browser to
//      /__gate?t=<pass>.
//   2. This checks the signature, the time and that it was never used before,
//      then sets a cookie good for 14 days and sends the browser to the globe.
//   3. Every other request needs that cookie, or gets a page saying where to go.
//
// Both sides share GEV_GATE_SECRET. Changing it signs everyone out. Plain Node,
// no dependencies. Installed and started by ai-hq: scripts/install-gods-eye.sh.
//
// The same door also lets members watch the owner's telescope: /scope is the
// viewer page, and the live video comes from this server's relay (GEV_SCOPE_URL),
// which takes ONE copy over Tailscale however many watch, from either
//   /ipad/     the owner's iPad or iPhone sending its own screen (port 1935), or
//   /seestar/  the laptop next to the telescope (GEV_SCOPE_BOX,
//              scripts/install-scope-bridge.sh), pulled only while someone watches.
import { createServer, request } from 'node:http';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { connect } from 'node:net';
import { handleSky } from './gate-sky.mjs';

const SECRET = process.env.GEV_GATE_SECRET || '';
const LISTEN = Number(process.env.GATE_PORT || 4180);
const UPSTREAM = Number(process.env.UPSTREAM_PORT || 4173);
const SCOPE = process.env.GEV_SCOPE_URL ? new URL(process.env.GEV_SCOPE_URL) : null;
const BOX = process.env.GEV_SCOPE_BOX ? new URL(`rtsp://${process.env.GEV_SCOPE_BOX}`) : null;
const SCOPE_API = process.env.GEV_SCOPE_API ? new URL(process.env.GEV_SCOPE_API) : null;
const STREAMS = ['/ipad/', '/seestar/'];
let SCOPE_PAGE = '';
try { SCOPE_PAGE = readFileSync(new URL('./scope.html', import.meta.url), 'utf8'); } catch { /* no telescope page installed */ }
const COOKIE = 'gev_pass';
const COOKIE_DAYS = 14;
if (SECRET.length < 32) {
  console.error('GEV_GATE_SECRET is missing or too short; refusing to start.');
  process.exit(1);
}

const b64 = (buf) => Buffer.from(buf).toString('base64url');
// The purpose is signed in, so a two-minute pass can never be replayed as a
// cookie or the other way round.
const sign = (purpose, body) => b64(createHmac('sha256', SECRET).update(`${purpose}.${body}`).digest());

/** "<body>.<sig>" → the parsed body, or null if forged, malformed or expired. */
function verify(purpose, token) {
  const [body, sig] = String(token || '').split('.');
  if (!body || !sig) return null;
  const want = Buffer.from(sign(purpose, body));
  const got = Buffer.from(sig);
  if (want.length !== got.length || !timingSafeEqual(want, got)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return Number(data.exp) > Date.now() / 1000 ? data : null;
  } catch {
    return null;
  }
}

// Passes already used, until they would have expired anyway.
const used = new Map();
function firstUse(nonce, exp) {
  const now = Date.now() / 1000;
  for (const [n, e] of used) if (e < now) used.delete(n);
  if (!nonce || used.has(nonce)) return false;
  used.set(nonce, exp);
  return true;
}

function readCookie(req) {
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === COOKIE) return part.slice(i + 1).trim();
  }
  return '';
}

const PAGE = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>God's Eye View</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1220;color:#e6ebee;font:16px/1.5 system-ui,sans-serif}
main{max-width:30rem;padding:24px}h1{font-weight:500;font-size:1.5rem;margin:0 0 .5rem}p{color:#9aa8ad}</style>
<main><h1>Open this from the Inner Hotel Circle</h1>
<p>God's Eye View is for Insiders. In the Circle app, go to your profile, tap God's Eye View, then Open. This browser is let in for two weeks after that.</p></main>`;

function deny(res, status = 401) {
  res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
  res.end(PAGE);
}

// Which telescope stream is there, if any: { on, src: 'ipad' | 'seestar' }.
// The iPad counts when it is sending right now (the relay says so); the laptop
// when it is on the tailnet (only a connection is opened, which doesn't wake the
// telescope or use its data). Asked at most every 15 seconds, so the globe's
// telescope button doesn't knock at every page load.
let scopeSeen = { at: 0, state: { on: false } };
function ipadLive() {
  if (!SCOPE_API) return Promise.resolve(false);
  return new Promise((resolve) => {
    const r = request({ host: SCOPE_API.hostname, port: SCOPE_API.port, path: '/v3/paths/get/ipad', timeout: 3000 }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => { try { resolve(res.statusCode === 200 && JSON.parse(body).ready === true); } catch { resolve(false); } });
    });
    r.on('timeout', () => r.destroy());
    r.on('error', () => resolve(false));
    r.end();
  });
}
function boxUp() {
  if (!BOX) return Promise.resolve(false);
  return new Promise((resolve) => {
    const done = (up) => { s.destroy(); resolve(up); };
    const s = connect({ host: BOX.hostname, port: Number(BOX.port || 8554), timeout: 4000 });
    s.on('connect', () => done(true));
    s.on('timeout', () => done(false));
    s.on('error', () => done(false));
  });
}
async function scopeState() {
  if (!SCOPE) return { on: false };
  if (Date.now() - scopeSeen.at < 15_000) return scopeSeen.state;
  const state = (await ipadLive()) ? { on: true, src: 'ipad' }
    : (await boxUp()) ? { on: true, src: 'seestar' } : { on: false };
  scopeSeen = { at: Date.now(), state };
  return state;
}

// The live video, passed through from the relay. Only reading, only its two
// stream paths, and the member's pass cookie stays here.
function toScope(req, res, url) {
  if (!SCOPE) return void res.writeHead(404, { 'content-type': 'text/plain' }).end('No telescope here.');
  if (req.method !== 'GET' && req.method !== 'HEAD') return void res.writeHead(405).end();
  const headers = {};
  for (const k of ['accept', 'range', 'user-agent', 'if-none-match', 'if-modified-since']) {
    if (req.headers[k]) headers[k] = req.headers[k];
  }
  const cookie = String(req.headers.cookie || '').split(';').map((s) => s.trim())
    .filter((s) => s && !s.startsWith(`${COOKIE}=`)).join('; ');
  if (cookie) headers.cookie = cookie;
  const up = request({ host: SCOPE.hostname, port: SCOPE.port || 80, method: req.method,
    path: url.pathname + url.search, headers, timeout: 30_000 }, (r) => {
    res.writeHead(r.statusCode || 502, r.headers);
    r.pipe(res);
  });
  up.on('timeout', () => up.destroy());
  up.on('error', () => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain' });
    res.end('The telescope is offline.');
  });
  up.end();
}

const server = createServer((req, res) => {
  const url = new URL(req.url, 'http://gate');

  if (url.pathname === '/__gate') {
    const pass = verify('pass', url.searchParams.get('t'));
    if (!pass || !firstUse(pass.n, pass.exp)) return deny(res, 403);
    const exp = Math.floor(Date.now() / 1000) + COOKIE_DAYS * 86400;
    const body = b64(JSON.stringify({ m: pass.m, exp }));
    res.writeHead(303, {
      location: '/',
      'cache-control': 'no-store',
      'set-cookie': `${COOKIE}=${body}.${sign('cookie', body)}; Max-Age=${COOKIE_DAYS * 86400}; Path=/; Secure; HttpOnly; SameSite=Lax`,
    });
    return res.end();
  }

  const member = verify('cookie', readCookie(req));
  if (!member) return deny(res);

  // The Sky panel's data: the telescope's spot, planes near it, tonight's clouds.
  if (handleSky(req, res, url, member)) return;

  if (url.pathname === '/scope/status') {
    return void scopeState().then((state) => {
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      res.end(JSON.stringify(state));
    });
  }
  if (url.pathname === '/scope' || url.pathname === '/scope/') {
    if (!SCOPE || !SCOPE_PAGE) return void res.writeHead(404, { 'content-type': 'text/plain' }).end('No telescope here.');
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(SCOPE_PAGE);
  }
  if (STREAMS.some((p) => url.pathname.startsWith(p))) return toScope(req, res, url);

  const up = request({ host: '127.0.0.1', port: UPSTREAM, method: req.method, path: req.url, headers: req.headers }, (r) => {
    res.writeHead(r.statusCode || 502, r.headers);
    r.pipe(res);
  });
  up.on('error', () => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain' });
    res.end('God\'s Eye View is starting or stopped. Try again in a minute.');
  });
  req.pipe(up);
});

// No WebSockets through the door: nothing the keyless app uses needs one, and
// every route left out is one less way in.
server.on('upgrade', (_req, socket) => socket.destroy());
server.headersTimeout = 15_000;
server.requestTimeout = 120_000;
server.listen(LISTEN, '127.0.0.1', () => console.log(`gate on 127.0.0.1:${LISTEN} → 127.0.0.1:${UPSTREAM}`));
