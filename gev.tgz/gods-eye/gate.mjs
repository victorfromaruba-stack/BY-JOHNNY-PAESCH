// The door in front of God's Eye View. Tailscale Funnel puts it on the public
// internet; this lets in only browsers that came from the Inner Hotel Circle.
//
//   1. A signed-in, active Insider taps "Open" in the Circle. The Circle's
//      gev-pass function (BY-JOHNNY-PAESCH: circle/supabase/functions/gev-pass)
//      signs a pass good for two minutes and one use, and sends the browser to
//      /__gate?t=<pass>.
//   2. This checks the signature, the time and that it was never used before,
//      then sets a cookie good for 14 days and sends the browser to the globe.
//   3. Every other request needs that cookie, or gets a page saying where to go.
//
// Both sides share GEV_GATE_SECRET. Changing it signs everyone out. Plain Node,
// no dependencies. Installed and started by ai-hq: scripts/install-gods-eye.sh.
import { createServer, request } from 'node:http';
import { createHmac, timingSafeEqual } from 'node:crypto';

const SECRET = process.env.GEV_GATE_SECRET || '';
const LISTEN = Number(process.env.GATE_PORT || 4180);
const UPSTREAM = Number(process.env.UPSTREAM_PORT || 4173);
const COOKIE = 'gev_pass';
const COOKIE_DAYS = 14;
if (SECRET.length < 32) {
  console.error('GEV_GATE_SECRET is missing or too short; refusing to start.');
  process.exit(1);
}

const b64 = (buf) => Buffer.from(buf).toString('base64url');
// The purpose is signed in, so a two-minute pass can never be replayed as a
// cookie or the other way round.
const sign = (purpose, body) => b64(createHmac('sha256', SECRET).update(`${purpose}.${body}`).digest());

/** "<body>.<sig>" → the parsed body, or null if forged, malformed or expired. */
function verify(purpose, token) {
  const [body, sig] = String(token || '').split('.');
  if (!body || !sig) return null;
  const want = Buffer.from(sign(purpose, body));
  const got = Buffer.from(sig);
  if (want.length !== got.length || !timingSafeEqual(want, got)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return Number(data.exp) > Date.now() / 1000 ? data : null;
  } catch {
    return null;
  }
}

// Passes already used, until they would have expired anyway.
const used = new Map();
function firstUse(nonce, exp) {
  const now = Date.now() / 1000;
  for (const [n, e] of used) if (e < now) used.delete(n);
  if (!nonce || used.has(nonce)) return false;
  used.set(nonce, exp);
  return true;
}

function readCookie(req) {
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === COOKIE) return part.slice(i + 1).trim();
  }
  return '';
}

const PAGE = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>God's Eye View</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1220;color:#e6ebee;font:16px/1.5 system-ui,sans-serif}
main{max-width:30rem;padding:24px}h1{font-weight:500;font-size:1.5rem;margin:0 0 .5rem}p{color:#9aa8ad}</style>
<main><h1>Open this from the Inner Hotel Circle</h1>
<p>God's Eye View is for Insiders. In the Circle app, go to your profile, tap God's Eye View, then Open. This browser is let in for two weeks after that.</p></main>`;

function deny(res, status = 401) {
  res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
  res.end(PAGE);
}

const server = createServer((req, res) => {
  const url = new URL(req.url, 'http://gate');

  if (url.pathname === '/__gate') {
    const pass = verify('pass', url.searchParams.get('t'));
    if (!pass || !firstUse(pass.n, pass.exp)) return deny(res, 403);
    const exp = Math.floor(Date.now() / 1000) + COOKIE_DAYS * 86400;
    const body = b64(JSON.stringify({ m: pass.m, exp }));
    res.writeHead(303, {
      location: '/',
      'cache-control': 'no-store',
      'set-cookie': `${COOKIE}=${body}.${sign('cookie', body)}; Max-Age=${COOKIE_DAYS * 86400}; Path=/; Secure; HttpOnly; SameSite=Lax`,
    });
    return res.end();
  }

  if (!verify('cookie', readCookie(req))) return deny(res);

  const up = request({ host: '127.0.0.1', port: UPSTREAM, method: req.method, path: req.url, headers: req.headers }, (r) => {
    res.writeHead(r.statusCode || 502, r.headers);
    r.pipe(res);
  });
  up.on('error', () => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain' });
    res.end('God\'s Eye View is starting or stopped. Try again in a minute.');
  });
  req.pipe(up);
});

// No WebSockets through the door: nothing the keyless app uses needs one, and
// every route left out is one less way in.
server.on('upgrade', (_req, socket) => socket.destroy());
server.headersTimeout = 15_000;
server.requestTimeout = 120_000;
server.listen(LISTEN, '127.0.0.1', () => console.log(`gate on 127.0.0.1:${LISTEN} → 127.0.0.1:${UPSTREAM}`));
