#!/usr/bin/env bash
#
# God's Eye View (github.com/bilawalsidhu/gods-eye-view, MIT): a live 3D globe of
# planes, ships, satellites, earthquakes and public cameras, for Inner Hotel
# Circle members. Runs on this server and is on the public internet through
# Tailscale Funnel at
#   https://<this-server>.<tailnet>.ts.net:10000/
# but behind a door (gods-eye/gate.mjs) that only lets in a browser the Circle
# sent with a one-time pass (BY-JOHNNY-PAESCH: circle/supabase/functions/gev-pass).
# The owner chose this over tailnet-only on 2026-10-10 so friends need no app.
#
#   sudo bash scripts/install-gods-eye.sh          # install, or update to the version pinned below
#   sudo bash scripts/install-gods-eye.sh --keys   # add or change feature keys, one question each, then rebuild
#   sudo bash scripts/install-gods-eye.sh --undo   # remove everything this added
#
# Runs on hq (the owner's choice; any of the servers works). The app and the
# door listen on 127.0.0.1 only; Funnel carries port 10000 to the door and
# nothing else. Both run as their own
# 'godseye' account, not as 'openclaw', so they can't read the agents' keys and
# the agents can't change their code.
#
# The door's secret is made here, kept in /etc/ai-hq/gods-eye.env, and never
# printed. The Circle's gev-pass function needs the same value (see the end).
#
# Keys switch on more features; it works without any. --keys asks for each one
# with the typing hidden and keeps them in /etc/ai-hq/gods-eye.env (root-only).
# The owner chose every feature, the two paid ones included, on 2026-10-11.
# OpenAI (voice) and Google (direct 3D tiles, place search) bill per use by any
# member let in: each needs a monthly limit set at the provider. Voice runs on
# the mini model unless OPENAI_REALTIME_MODEL is set in the env file. Browser-side
# keys (Cesium, Google, Mapillary) are visible to members; restrict them to this
# server's address at the provider.
#
# The phone layout (gods-eye/mobile.css, mobile.js) is added to the built page;
# computers keep the app exactly as its author made it.
#
# The door also shows the owner's telescope live at /scope (owner's call,
# 2026-10-12). A relay here (MediaMTX, as godseye, on 127.0.0.1) takes ONE copy
# of the video over Tailscale from the box next to the telescope
# (scripts/install-scope-bridge.sh, named 'scope'), only while someone watches,
# and hands it to every member watching: that box is often on phone data.
# Or the owner's iPad/iPhone sends its screen to this server's public port 1935
# (RTMP with a long password, send-only; owner's call 2026-10-13).
# GEV_SCOPE_BOX=<name>:8554 in the env file points at a box with another name.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# shellcheck source-path=SCRIPTDIR source=lib.sh
source ./lib.sh
need_root

# What gets installed. Bump these on purpose, after reading what changed.
GEV_TAG=v0.2.1
GEV_COMMIT=aa16b7c3b0166a89d8c7a6089e0aff53a22faaee
NODE_VERSION=v24.21.0

base=/opt/gods-eye             # code and Node, owned by root
state=/var/lib/gods-eye        # the app's caches and logs, owned by godseye
envfile=/etc/ai-hq/gods-eye.env
unit=/etc/systemd/system/gods-eye.service
gate_unit=/etc/systemd/system/gods-eye-gate.service
port=10000                     # Funnel HTTPS port (443 and 8443 are taken)
local_port=4173                # the app
gate_port=4180                 # the door in front of it
scope_port=4190                # the telescope relay, for the door
scope_api_port=4191            # the relay's "what's live" answers, for the door
ingest_port=1935               # public: the owner's iPad sends the telescope here (RTMP + password)
scope_unit=/etc/systemd/system/gods-eye-scope.service
# The relay (github.com/bluenviron/mediamtx). Bump on purpose; checksums are in
# each release's checksums.sha256. Same version as scripts/install-scope-bridge.sh.
MTX_VERSION=v1.21.1
declare -A MTX_SHA256=(
  [x64]=653abc672a3e693f8d3b2717752492fdcfb8072291ec108d03d3dd857411b0ee
  [arm64]=6a3aa635fb60ea9b8d566ec306f0a42ff1b6b52a3942bc2baffbe55880d4c3dd
)
user=godseye
# name | what it switches on | where to get it
KEY_TABLE=(
  "CESIUM_ION_TOKEN|3D cities and terrain (free)|cesium.com/ion > Access Tokens"
  "AISSTREAM_API_KEY|live ships (free)|aisstream.io > API Keys"
  "FIRMS_MAP_KEY|live wildfires (free)|firms.modaps.eosdis.nasa.gov/api/map_key"
  "TOMTOM_API_KEY|live traffic (free tier)|developer.tomtom.com > Keys"
  "MAPILLARY_CLIENT_TOKEN|street-level photos (free)|mapillary.com/dashboard/developers"
  "OPENSKY_CLIENT_ID|more flights, part 1 of 2 (free)|opensky-network.org > Account > API client"
  "OPENSKY_CLIENT_SECRET|more flights, part 2 of 2 (free)|same page as the client ID"
  "LL2_API_TOKEN|more space launches (free)|thespacedevs.com"
  "OPENAI_API_KEY|voice control (PAID per minute)|platform.openai.com > API keys"
  "GOOGLE_MAPS_API_KEY|Google 3D tiles + place search (PAID per use)|console.cloud.google.com > APIs > Credentials"
)
KEYS=(); for row in "${KEY_TABLE[@]}"; do KEYS+=("${row%%|*}"); done
# Settings, not secrets: read from the env file too when present.
SETTINGS=(OPENAI_REALTIME_MODEL OPENAI_REALTIME_MODEL_MINI GEV_RATELIMIT_OPENAI_PER_MIN GEV_RATELIMIT_GOOGLE_PER_MIN)

# Ours: pointing at the door, or at the app directly (the tailnet-only version).
ours() { tailscale serve status --json 2>/dev/null | grep -qE "127\.0\.0\.1:($gate_port|$local_port)"; }

if [[ "${1:-}" == --undo ]]; then
  head1 "Removing God's Eye View"
  if ours; then
    tailscale funnel --https="$port" off >/dev/null 2>&1 || true
    tailscale serve --https="$port" off >/dev/null 2>&1 || true
  fi
  ok "port $port closed (off the internet and the tailnet)"
  systemctl disable --now gods-eye-gate.service gods-eye-scope.service gods-eye.service >/dev/null 2>&1 || true
  if have ufw && ufw status | grep -q "^$ingest_port/tcp .*ai-hq: telescope"; then
    ufw delete allow "$ingest_port/tcp" >/dev/null && ok "firewall: port $ingest_port closed again"
  fi
  rm -f "$unit" "$gate_unit" "$scope_unit"; systemctl daemon-reload
  ok "service removed"
  rm -rf "$base" "$state"
  if id "$user" >/dev/null 2>&1; then userdel "$user"; fi
  ok "removed $base, $state and the '$user' account"
  [[ ! -f "$envfile" ]] || say "  Kept $envfile (keys and the door's secret). Delete it yourself if you don't want them."
  exit 0
fi
if [[ "${1:-}" == --keys ]]; then
  [[ -r /dev/tty ]] || die "--keys asks questions, so run it in a terminal"
  head1 "Feature keys"
  say "  For each one: paste the key and press Enter. Typing is hidden."
  say "  Just Enter keeps what is there; a single - removes it."
  install -d -m 755 /etc/ai-hq
  (umask 077; touch "$envfile"); chmod 600 "$envfile"; chown root:root "$envfile"
  for row in "${KEY_TABLE[@]}"; do
    IFS='|' read -r k what where <<<"$row"
    if grep -qE "^$k=.+" "$envfile"; then now="set"; else now="not set"; fi
    say
    say "  $what   [$now]"
    dim "get it at: $where"
    read -r -s -p "  $k: " v </dev/tty || v=""
    say
    v="$(printf '%s' "$v" | tr -d '[:space:]"'"'")"
    [[ -z "$v" ]] && continue
    tmp="$(mktemp "$envfile.XXXX")"; chmod 600 "$tmp"
    grep -vE "^$k=" "$envfile" >"$tmp" || true
    [[ "$v" == - ]] || printf '%s=%s\n' "$k" "$v" >>"$tmp"
    mv "$tmp" "$envfile"
    if [[ "$v" == - ]]; then ok "$k removed"; else ok "$k saved"; fi
  done
  say
  say "  Rebuilding so the new keys take effect…"
  set --
fi
[[ -z "${1:-}" ]] || die "usage: sudo bash $0   or   sudo bash $0 --keys   or   sudo bash $0 --undo"

have git || die "git is missing: sudo apt install -y git"
have curl || die "curl is missing: sudo apt install -y curl"
have python3 || die "python3 is missing: sudo apt install -y python3"
if ! { have tailscale && tailscale status --peers=false >/dev/null 2>&1; }; then
  die "Tailscale isn't running here yet: sudo bash scripts/setup-tailscale.sh <name>"
fi
if tailscale serve status --json 2>/dev/null | grep -q "\"[^\"]*:$port\"" && ! ours; then
  die "tailnet port $port already serves something else. See: tailscale serve status"
fi
if ss -Hltn "sport = :$local_port" 2>/dev/null | grep -q . && ! systemctl is-active --quiet gods-eye.service; then
  die "something else listens on 127.0.0.1:$local_port. See: sudo ss -ltnp 'sport = :$local_port'"
fi
if ss -Hltn "sport = :$gate_port" 2>/dev/null | grep -q . && ! systemctl is-active --quiet gods-eye-gate.service; then
  die "something else listens on 127.0.0.1:$gate_port. See: sudo ss -ltnp 'sport = :$gate_port'"
fi
if ss -Hltn "sport = :$scope_port" 2>/dev/null | grep -q . && ! systemctl is-active --quiet gods-eye-scope.service; then
  die "something else listens on 127.0.0.1:$scope_port. See: sudo ss -ltnp 'sport = :$scope_port'"
fi

head1 "Account and folders"
if ! id "$user" >/dev/null 2>&1; then
  useradd --system --home-dir "$state" --no-create-home --shell /usr/sbin/nologin "$user"
fi
install -d -m 755 -o root -g root "$base"
install -d -m 750 -o "$user" -g "$user" "$state"
ok "'$user' account (no login, no sudo); code in $base, caches in $state"

head1 "Node.js $NODE_VERSION"
case "$(uname -m)" in
  x86_64) arch=x64 ;;
  aarch64) arch=arm64 ;;
  *) die "unsupported CPU: $(uname -m)" ;;
esac
node_dir="$base/node-$NODE_VERSION"
if [[ ! -x "$node_dir/bin/node" ]]; then
  tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
  tarball="node-$NODE_VERSION-linux-$arch.tar.xz"
  curl -fsSL -o "$tmp/$tarball" "https://nodejs.org/dist/$NODE_VERSION/$tarball"
  curl -fsSL -o "$tmp/SHASUMS256.txt" "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt"
  (cd "$tmp" && grep " $tarball\$" SHASUMS256.txt | sha256sum -c --quiet -) \
    || die "Node download didn't match its published checksum. Nothing installed."
  tar -xJf "$tmp/$tarball" -C "$tmp"
  rm -rf "$node_dir"; mv "$tmp/node-$NODE_VERSION-linux-$arch" "$node_dir"
  chown -R root:root "$node_dir"
fi
ok "$("$node_dir/bin/node" -v) in $node_dir (checksum verified, used only by this app)"

head1 "God's Eye View $GEV_TAG"
dns="$(tailscale status --json --peers=false | python3 -c 'import json,sys; print(json.load(sys.stdin)["Self"]["DNSName"].rstrip("."))')"
# Keys from the env file, only the ones listed above. The browser-side ones are
# baked into the page at build time, so a changed key needs a re-run.
envs=(HOME="$state" PATH="$node_dir/bin:/usr/bin:/bin" npm_config_cache="$state/.npm" npm_config_update_notifier=false)
for k in HTTPS_PROXY HTTP_PROXY NO_PROXY NODE_EXTRA_CA_CERTS; do
  if [[ -n "${!k:-}" ]]; then envs+=("$k=${!k}"); fi
done
# The door's secret: made once, kept across re-runs. Changing it signs everyone out.
install -d -m 755 /etc/ai-hq
if ! grep -qE '^GEV_GATE_SECRET=.{32,}' "$envfile" 2>/dev/null; then
  (umask 077; printf 'GEV_GATE_SECRET=%s\n' "$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')" >>"$envfile")
  ok "made the door's secret in $envfile"
fi
gate_secret="$(grep -E '^GEV_GATE_SECRET=' "$envfile" | tail -1 | cut -d= -f2-)"
if [[ -f "$envfile" ]]; then
  chmod 600 "$envfile"; chown root:root "$envfile"
  for k in "${KEYS[@]}" "${SETTINGS[@]}"; do
    v="$(grep -E "^$k=" "$envfile" | tail -1 | cut -d= -f2- | tr -d '"'"'" || true)"
    if [[ -n "$v" ]]; then envs+=("$k=$v"); ok "using $k from $envfile"; fi
  done
fi
# Money defaults, each overridable from the env file. Voice runs on the mini model
# (about a third of the standard one's price) whichever tier a member picks. The
# app's per-address throttles become one shared limit behind the door, since every
# request reaches the app from 127.0.0.1; Google's is tightened from 120 to 60.
has_env() { local k; for k in "${envs[@]}"; do [[ "${k%%=*}" == "$1" ]] && return 0; done; return 1; }
has_env OPENAI_REALTIME_MODEL || envs+=("OPENAI_REALTIME_MODEL=gpt-realtime-2.1-mini")
has_env GEV_RATELIMIT_GOOGLE_PER_MIN || envs+=("GEV_RATELIMIT_GOOGLE_PER_MIN=60")
build="$base/app-$GEV_TAG.new"
rm -rf "$build"
git -c advice.detachedHead=false clone -q --depth 1 --branch "$GEV_TAG" https://github.com/bilawalsidhu/gods-eye-view.git "$build"
[[ "$(git -C "$build" rev-parse HEAD)" == "$GEV_COMMIT" ]] \
  || { rm -rf "$build"; die "$GEV_TAG doesn't point at the commit this script expects. Nothing changed."; }
# Built as godseye, never root: the build runs the app's own code. No install
# scripts from dependencies (--ignore-scripts); the build doesn't need any.
chown -R "$user:$user" "$build"
if ! (cd "$build" && runuser -u "$user" -- env -i "${envs[@]}" npm ci --ignore-scripts --no-audit --no-fund --loglevel=error >/dev/null \
      && runuser -u "$user" -- env -i "${envs[@]}" node node_modules/vite/bin/vite.js build --logLevel error >/dev/null); then
  rm -rf "$build"
  die "the build failed; the version already running (if any) is untouched."
fi
# Phone layout: two files beside the built page, linked from its <head> after the
# app's own styles. Only narrow screens use them.
install -m 644 "$(cd .. && pwd)/gods-eye/mobile.css" "$build/dist/gev-mobile.css"
install -m 644 "$(cd .. && pwd)/gods-eye/mobile.js" "$build/dist/gev-mobile.js"
python3 - "$build/dist/index.html" <<'PY' || die "couldn't add the phone layout to the page"
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
tag = '<link rel="stylesheet" href="/gev-mobile.css" /><script src="/gev-mobile.js" defer></script>\n'
if 'gev-mobile.js' not in s:
    assert s.count('</head>') == 1, 'no single </head>'
    s = s.replace('</head>', tag + '</head>')
    open(p, 'w', encoding='utf-8').write(s)
PY
ok "phone layout added"
# Fun scenes (meteorites, UFOs, shipwrecks, movie spots, an Aruba tour): their data
# packs go where the app's own pack loader looks (/scene-assets/), and a small
# script that runs before the app adds the scenes to its Scenes panel. The script
# is made and checked by the app's own code, so it runs as godseye like the build.
fun="$(cd .. && pwd)/gods-eye/scenes"
install -d -m 755 "$build/dist/scene-assets/fun" "$build/.fun"
install -m 644 "$fun"/packs/*.geojson "$build/dist/scene-assets/fun/"
install -m 644 "$fun/build_seed.mjs" "$fun/scenes.json" "$build/.fun/"
chown -R "$user:$user" "$build/.fun" "$build/dist/scene-assets"
(cd "$build" && runuser -u "$user" -- env -i "${envs[@]}" node .fun/build_seed.mjs "$build" .fun/scenes.json dist/gev-scenes.js >/dev/null) \
  || { rm -rf "$build"; die "the fun scenes didn't pass the app's checks; the version already running (if any) is untouched."; }
rm -rf "$build/.fun"
python3 - "$build/dist/index.html" <<'PY' || die "couldn't add the fun scenes to the page"
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
# A plain script runs before the app's module script, so the scenes are in place when it starts.
if 'gev-scenes.js' not in s:
    assert s.count('<head>') == 1, 'no single <head>'
    s = s.replace('<head>', '<head>\n<script src="/gev-scenes.js"></script>')
    open(p, 'w', encoding='utf-8').write(s)
PY
ok "fun scenes added ($(ls "$build/dist/scene-assets/fun" | wc -l) data packs)"
# Live telescope button: shows itself only while the telescope's home box answers.
install -m 644 "$(cd .. && pwd)/gods-eye/scope/button.js" "$build/dist/gev-scope.js"
python3 - "$build/dist/index.html" <<'PY' || die "couldn't add the telescope button to the page"
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
if 'gev-scope.js' not in s:
    assert s.count('</head>') == 1, 'no single </head>'
    s = s.replace('</head>', '<script src="/gev-scope.js" defer></script>\n</head>')
    open(p, 'w', encoding='utf-8').write(s)
PY
ok "telescope button added"
# The running copy is root's and read-only to the app. That's why the service
# loads vite.config.js with --configLoader native: the default loader writes a
# temporary file into node_modules on every start.
chown -R root:root "$build"
rm -rf "$base/app.old"
if [[ -d "$base/app" ]]; then mv "$base/app" "$base/app.old"; fi
mv "$build" "$base/app"
rm -rf "$base/app.old"
ok "built from commit ${GEV_COMMIT:0:12}"

head1 "Service"
{
  echo "[Unit]"
  echo "Description=God's Eye View (live globe), behind gods-eye-gate"
  echo "After=network-online.target"
  echo "Wants=network-online.target"
  echo
  echo "[Service]"
  echo "User=$user"
  echo "Group=$user"
  echo "WorkingDirectory=$state"
  for e in "${envs[@]}"; do [[ "$e" == npm_config_* ]] || printf 'Environment="%s"\n' "$e"; done
  echo "Environment=GEV_ALLOWED_HOSTS=$dns"
  echo "ExecStart=$node_dir/bin/node $base/app/node_modules/vite/bin/vite.js preview $base/app --configLoader native --host 127.0.0.1 --port $local_port --strictPort"
  echo "Restart=on-failure"
  echo "RestartSec=5"
  echo "Nice=10"
  echo "MemoryMax=1500M"
  echo "NoNewPrivileges=yes"
  echo "ProtectSystem=strict"
  echo "ProtectHome=yes"
  echo "ReadWritePaths=$state"
  echo "PrivateTmp=yes"
  echo "PrivateDevices=yes"
  echo
  echo "[Install]"
  echo "WantedBy=multi-user.target"
} >"$unit"
# Keys may be in the unit; root-only like the env file.
chmod 600 "$unit"
systemctl daemon-reload
systemctl enable gods-eye.service >/dev/null
systemctl restart gods-eye.service
for _ in $(seq 1 30); do
  curl -fs -o /dev/null "http://127.0.0.1:$local_port/" && break
  sleep 1
done
curl -fs -o /dev/null "http://127.0.0.1:$local_port/" \
  || die "the app didn't start. See: journalctl -u gods-eye.service -n 50"
ok "running on 127.0.0.1:$local_port"

head1 "Telescope relay (MediaMTX $MTX_VERSION)"
# The box next to the telescope, over Tailscale. Until it exists the door just
# says the telescope is offline.
scope_box="$(grep -E '^GEV_SCOPE_BOX=' "$envfile" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"'"'" || true)"
: "${scope_box:=scope.${dns#*.}:8554}"
[[ "$scope_box" =~ ^[A-Za-z0-9.-]+:[0-9]+$ ]] || die "GEV_SCOPE_BOX in $envfile should look like name:8554"
# Or an iPad/iPhone sends its own screen (the Seestar app, in any mode) with a
# free streaming app (PRISM Live Studio), without Tailscale: plain RTMP to this
# server's public address, port $ingest_port, the one port opened for it (owner's
# call, 2026-10-13). RTMP isn't encrypted, so the long password, made once and
# kept in the env file, is what keeps strangers from sending; it can only send
# to the iPad stream, never read or change anything else. New password:
# delete its line in the env file and run this again.
public_ip="$(python3 -c 'import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("1.1.1.1", 53)); print(s.getsockname()[0])')"
[[ "$public_ip" =~ ^[0-9.]+$ ]] || die "couldn't find this server's own address"
case "$public_ip" in
  10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*)
    warn "this server's address is private ($public_ip): the iPad can only reach it if your provider forwards port $ingest_port to it" ;;
esac
if ! grep -qE '^GEV_SCOPE_PUBLISH_PASS=[0-9a-f]{32,}$' "$envfile" 2>/dev/null; then
  tmp="$(mktemp "$envfile.XXXX")"; chmod 600 "$tmp"
  grep -vE '^GEV_SCOPE_PUBLISH_PASS=' "$envfile" >"$tmp" || true
  printf 'GEV_SCOPE_PUBLISH_PASS=%s\n' "$(python3 -c 'import secrets; print(secrets.token_hex(16))')" >>"$tmp"
  mv "$tmp" "$envfile"
  ok "made the iPad stream's password in $envfile"
fi
publish_pass="$(grep -E '^GEV_SCOPE_PUBLISH_PASS=' "$envfile" | tail -1 | cut -d= -f2-)"
mtx="$base/mediamtx-$MTX_VERSION/mediamtx"
if [[ ! -x "$mtx" ]]; then
  tmp="$(mktemp -d)"
  tarball="mediamtx_${MTX_VERSION}_linux_$([[ $arch == x64 ]] && echo amd64 || echo arm64).tar.gz"
  curl -fsSL -o "$tmp/$tarball" "https://github.com/bluenviron/mediamtx/releases/download/$MTX_VERSION/$tarball"
  echo "${MTX_SHA256[$arch]}  $tmp/$tarball" | sha256sum -c --quiet - \
    || { rm -rf "$tmp"; die "the relay download's checksum is wrong. Nothing else changed."; }
  tar -xzf "$tmp/$tarball" -C "$tmp" mediamtx LICENSE
  install -d -m 755 -o root -g root "$(dirname "$mtx")"
  install -m 755 -o root -g root "$tmp/mediamtx" "$mtx"
  install -m 644 -o root -g root "$tmp/LICENSE" "$(dirname "$mtx")/LICENSE"
  rm -rf "$tmp"
fi
cat >"$base/scope-relay.yml" <<EOF
# Written by scripts/install-gods-eye.sh; re-run it to change anything.
logLevel: warn
logDestinations: [stdout]
# Only the door, on this machine, may read and ask what's live. Only the
# owner's iPad/iPhone, with the password, may send, and only to 'ipad'.
authMethod: internal
authInternalUsers:
  - user: any
    pass:
    ips: ['127.0.0.1/32', '::1/128']
    permissions:
      - action: read
        path: seestar
      - action: read
        path: ipad
      - action: api
  - user: scope
    pass: '$publish_pass'
    ips: []
    permissions:
      - action: publish
        path: ipad
api: true
apiAddress: '127.0.0.1:$scope_api_port'
metrics: false
pprof: false
playback: false
rtsp: false
rtmp: true
rtmpAddress: '$public_ip:$ingest_port'
rtmpEncryption: "no"
webrtc: false
srt: false
moq: false
hls: true
hlsAddress: '127.0.0.1:$scope_port'
hlsAllowOrigins: []
paths:
  seestar:
    source: 'rtsp://$scope_box/seestar'
    rtspTransport: tcp
    # One copy from the telescope's box, only while someone watches.
    sourceOnDemand: true
    sourceOnDemandStartTimeout: 25s
    sourceOnDemandCloseAfter: 30s
  ipad:
    source: publisher
EOF
# The iPad's password is in it: readable by the relay's account only.
chown root:"$user" "$base/scope-relay.yml"; chmod 640 "$base/scope-relay.yml"
{
  echo "[Unit]"
  echo "Description=God's Eye View telescope relay: one copy from the telescope's box for every member watching"
  echo "After=network-online.target tailscaled.service"
  echo "Wants=network-online.target"
  echo
  echo "[Service]"
  echo "User=$user"
  echo "Group=$user"
  echo "ExecStart=$mtx $base/scope-relay.yml"
  echo "Restart=always"
  echo "RestartSec=5"
  echo "MemoryMax=300M"
  echo "NoNewPrivileges=yes"
  echo "ProtectSystem=strict"
  echo "ProtectHome=yes"
  echo "PrivateTmp=yes"
  echo "PrivateDevices=yes"
  echo
  echo "[Install]"
  echo "WantedBy=multi-user.target"
} >"$scope_unit"
systemctl daemon-reload
systemctl enable gods-eye-scope.service >/dev/null
systemctl restart gods-eye-scope.service
for _ in $(seq 1 10); do
  curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$scope_port/" && break
  sleep 1
done
curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$scope_port/" \
  || die "the telescope relay didn't start. See: journalctl -u gods-eye-scope.service -n 50"
ok "relay on 127.0.0.1:$scope_port, for the telescope's box at $scope_box"
# The one public opening for it. Only this rule; the rest of the firewall stays.
if have ufw && ufw status | grep -q 'Status: active'; then
  ufw allow "$ingest_port/tcp" comment "ai-hq: telescope video from the iPad (install-gods-eye.sh)" >/dev/null
  ok "firewall: port $ingest_port open for the iPad's video (undo removes it)"
fi
ok "the iPad sends to rtmp://$public_ip:$ingest_port/ (password needed)"
find "$base" -maxdepth 1 -name 'mediamtx-*' ! -path "$(dirname "$mtx")" -exec rm -rf {} +

head1 "The door"
install -m 644 -o root -g root "$(cd .. && pwd)/gods-eye/gate.mjs" "$base/gate.mjs"
install -m 644 -o root -g root "$(cd .. && pwd)/gods-eye/scope/scope.html" "$base/scope.html"
{
  echo "[Unit]"
  echo "Description=God's Eye View door: lets in browsers sent from the Inner Hotel Circle"
  echo "After=gods-eye.service"
  echo
  echo "[Service]"
  echo "User=$user"
  echo "Group=$user"
  echo "Environment=\"GEV_GATE_SECRET=$gate_secret\""
  echo "Environment=GATE_PORT=$gate_port"
  echo "Environment=UPSTREAM_PORT=$local_port"
  echo "Environment=GEV_SCOPE_URL=http://127.0.0.1:$scope_port"
  echo "Environment=GEV_SCOPE_BOX=$scope_box"
  echo "Environment=GEV_SCOPE_API=http://127.0.0.1:$scope_api_port"
  echo "ExecStart=$node_dir/bin/node $base/gate.mjs"
  echo "Restart=on-failure"
  echo "RestartSec=3"
  echo "MemoryMax=200M"
  echo "NoNewPrivileges=yes"
  echo "ProtectSystem=strict"
  echo "ProtectHome=yes"
  echo "PrivateTmp=yes"
  echo "PrivateDevices=yes"
  echo
  echo "[Install]"
  echo "WantedBy=multi-user.target"
} >"$gate_unit"
chmod 600 "$gate_unit"
systemctl daemon-reload
systemctl enable gods-eye-gate.service >/dev/null
systemctl restart gods-eye-gate.service
for _ in $(seq 1 15); do
  [[ "$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$gate_port/")" == 401 ]] && break
  sleep 1
done
[[ "$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$gate_port/")" == 401 ]] \
  || die "the door didn't start. See: journalctl -u gods-eye-gate.service -n 50"
ok "door on 127.0.0.1:$gate_port; checked: it turns away a browser with no pass"
if timeout 5 bash -c "exec 3<>/dev/tcp/${scope_box%:*}/${scope_box##*:}" 2>/dev/null; then
  ok "the telescope's box answers at $scope_box; members see it at /scope"
else
  dim "the telescope's box ($scope_box) isn't on right now (fine: scripts/install-scope-bridge.sh)."
  dim "If it is set up and this still says so, tag it in the Tailscale console: Machines → scope →"
  dim "Edit tags → tag:scope, with the telescope rules from policy/tailnet-policy.hujson."
fi

head1 "On the internet, through the door"
if tailscale funnel --bg --yes --https="$port" "http://127.0.0.1:$gate_port" >/dev/null 2>&1 \
   || tailscale funnel --bg --https="$port" "http://127.0.0.1:$gate_port"; then
  ok "https://$dns:$port/ (Funnel → door → app)"
else
  bad "tailscale funnel failed. Two settings in console.tailscale.com, then re-run this:"
  say "  DNS → Enable HTTPS, and Access controls → allow Funnel for this server"
  say "  (the 'funnel' attribute in nodeAttrs; the console's Funnel page offers to add it)."
  exit 1
fi
code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 "https://$dns:$port/" || true)"
if [[ "$code" == 401 ]]; then
  ok "checked: the public address answers, and turns away a browser with no pass"
else
  warn "the public address answered '$code' (401 expected). Give Funnel a minute on first use, then try again."
fi

say
say "  Last step, once (and again only if you delete $envfile): give the Circle's"
say "  gev-pass function the same secret and this address. On a computer with the"
say "  Supabase CLI logged in to the club's project:"
say
say "    supabase secrets set GEV_URL=https://$dns:$port GEV_GATE_SECRET=<value>"
say "    supabase functions deploy gev-pass"
say
say "  <value> is the GEV_GATE_SECRET line in $envfile on this server:"
say "    sudo grep GEV_GATE_SECRET $envfile"
say "  It's a password. Paste it straight into that command, nowhere else."
say
say "  Then in the Circle: Profile → God's Eye View → Open."
say
say "  Telescope from an iPad or iPhone (no Tailscale needed): in PRISM Live Studio,"
say "  add a Custom RTMP stream, then start its screen broadcast from Control Center:"
say "    Server URL:  rtmp://$public_ip:$ingest_port/"
say "    Stream key:  ipad?user=scope&pass=<password>"
say "  <password> is the GEV_SCOPE_PUBLISH_PASS line in $envfile:"
say "    sudo grep GEV_SCOPE_PUBLISH_PASS $envfile"
say "  If your server company has its own firewall (Hetzner: Firewalls in the Cloud"
say "  Console), allow TCP port $ingest_port there too."
say
say "  Undo everything: sudo bash scripts/install-gods-eye.sh --undo"
