# Shared helpers for the ai-hq scripts. Sourced, never run directly.
# shellcheck shell=bash

if [[ -t 1 ]]; then
  _B=$'\e[1m' _G=$'\e[32m' _Y=$'\e[33m' _R=$'\e[31m' _D=$'\e[2m' _N=$'\e[0m'
else
  _B='' _G='' _Y='' _R='' _D='' _N=''
fi

say()  { printf '%s\n' "$*"; }
head1(){ printf '\n%s== %s ==%s\n' "$_B" "$*" "$_N"; }
ok()   { printf '  %s✓%s %s\n' "$_G" "$_N" "$*"; }
warn() { printf '  %s!%s %s\n' "$_Y" "$_N" "$*"; }
bad()  { printf '  %s✗%s %s\n' "$_R" "$_N" "$*"; }
dim()  { printf '    %s%s%s\n' "$_D" "$*" "$_N"; }
die()  { printf '%serror:%s %s\n' "$_R" "$_N" "$*" >&2; exit 1; }

need_root() {
  [[ $EUID -eq 0 ]] || die "run this with sudo:  sudo bash $0"
}

have() { command -v "$1" >/dev/null 2>&1; }

# Ask a yes/no question. Default is NO. Honors ASSUME_YES=1 for automation.
confirm() {
  [[ "${ASSUME_YES:-0}" == 1 ]] && return 0
  local reply
  read -r -p "  $1 [y/N] " reply </dev/tty || return 1
  [[ "$reply" =~ ^[Yy]([Ee][Ss])?$ ]]
}

# A question only a person at a keyboard may answer: ASSUME_YES never counts,
# and no terminal means no. Used where a wrong "yes" could lock the owner out.
confirm_human() {
  local reply
  [[ -r /dev/tty ]] || return 1
  read -r -p "  $1 [y/N] " reply </dev/tty || return 1
  [[ "$reply" =~ ^[Yy]([Ee][Ss])?$ ]]
}

# Paths the caller typed are relative to where they stood, not to scripts/.
# Each script sets ORIG_PWD before it cd's.
abspath() {
  local p="$1"
  [[ "$p" == /* ]] || p="${ORIG_PWD:-$PWD}/$p"
  printf '%s' "$p"
}

# The human account that will own OpenClaw and log in over SSH.
# Defaults to whoever ran sudo; override with AIHQ_USER=name.
target_user() {
  local u="${AIHQ_USER:-${SUDO_USER:-}}"
  [[ -n "$u" && "$u" != root ]] || die "tell me which normal user to set up:  sudo AIHQ_USER=yourname $0"
  id "$u" >/dev/null 2>&1 || die "user '$u' does not exist (create it with: sudo adduser $u && sudo usermod -aG sudo $u)"
  printf '%s' "$u"
}

user_home() { getent passwd "$1" | cut -d: -f6; }

# Back up a file once per run, next to itself, before we touch it.
backup_file() {
  local f="$1"
  [[ -e "$f" ]] || return 0
  cp -a "$f" "$f.bak.$(date +%Y%m%d-%H%M%S)"
}

# ---- OpenClaw helpers ---------------------------------------------------------

# Who owns the OpenClaw state on this machine? Prefers the dedicated 'openclaw'
# user; falls back to root (the setup we're moving away from).
oc_owner() {
  if id openclaw >/dev/null 2>&1 && [[ -d "$(user_home openclaw)/.openclaw" ]]; then echo openclaw; return; fi
  if [[ -d /root/.openclaw ]]; then echo root; return; fi
  local d
  for d in /home/*/.openclaw; do
    [[ -d "$d" ]] && { stat -c %U "$d"; return; }
  done
  echo ""
}

# Run the openclaw CLI as its owner, with that user's systemd session so
# 'systemctl --user' based commands (gateway restart, node install) work.
# Usage: oc <user> <args...>
oc() {
  local u="$1"; shift
  local h uid rt
  h="$(user_home "$u")"; uid="$(id -u "$u")"; rt="/run/user/$uid"
  # sudo strips XDG_RUNTIME_DIR, and without it every 'systemctl --user' behind
  # 'openclaw gateway …' fails with "Failed to connect to bus". Put it back,
  # for root too.
  if [[ "$u" == root ]]; then
    XDG_RUNTIME_DIR="$rt" DBUS_SESSION_BUS_ADDRESS="unix:path=$rt/bus" openclaw "$@"
  else
    (cd "$h" && runuser -u "$u" -- env HOME="$h" USER="$u" XDG_RUNTIME_DIR="$rt" \
      DBUS_SESSION_BUS_ADDRESS="unix:path=$rt/bus" \
      PATH="$h/.local/bin:$h/.npm-global/bin:/usr/local/bin:/usr/bin:/bin" openclaw "$@")
  fi
}

# Is a gateway process answering on this machine?
gateway_listening() { ss -Hltn 'sport = :18789' 2>/dev/null | grep -q .; }

# "2026.9.6" -> 20260906, for comparisons. Empty if no version found.
oc_version_num() {
  grep -oE '[0-9]{4}\.[0-9]{1,2}\.[0-9]{1,3}' <<<"$1" | head -1 | awk -F. '{printf "%04d%02d%03d", $1, $2, $3}'
}
