#!/usr/bin/env bash
#
# The box next to the telescope: passes the Seestar's live video on to God's
# Eye View. Runs on the owner's laptop (or any Linux computer) on the same Wi-Fi
# as the telescope, usually a phone's hotspot out in the field. hq's telescope
# relay takes ONE copy from here over Tailscale while anyone watches, and hands
# it to every member at /scope, so phone data doesn't grow with the audience.
# The owner chose this on 2026-10-12.
#
#   sudo bash scripts/install-scope-bridge.sh                 # asks for the telescope's address
#   sudo bash scripts/install-scope-bridge.sh --rtsp 'rtsp://…'
#   sudo bash scripts/install-scope-bridge.sh --undo
#
# The address comes from the Seestar app: Settings → Advanced Feature → RTSP
# Address → Get (the telescope in Station Mode, on this Wi-Fi). It streams in
# Solar System and Landscape modes only.
#
# This box joins the tailnet as 'scope' with Tailscale SSH on, so the owner can
# look after it from a phone. The relay (MediaMTX, pinned and checksum-verified
# below) listens on this box's Tailscale address only, hands out video only (no
# publishing, no API), and only wakes the telescope's stream while someone
# watches. Nothing is opened on any router or hotspot.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# shellcheck source-path=SCRIPTDIR source=lib.sh
source ./lib.sh
need_root

# What gets installed. Bump on purpose, after reading what changed:
# github.com/bluenviron/mediamtx/releases (checksums.sha256 on each release).
MTX_VERSION=v1.21.1
declare -A MTX_SHA256=(
  [amd64]=653abc672a3e693f8d3b2717752492fdcfb8072291ec108d03d3dd857411b0ee
  [arm64]=6a3aa635fb60ea9b8d566ec306f0a42ff1b6b52a3942bc2baffbe55880d4c3dd
  [armv7]=d032bc572a07a139417db9584a33b91d48c7eb8f27e447645f25c259447e9c07
  [armv6]=47c0f461693e27df1fa6b3cf91dc550224fabffb96e9e7ec458c5f112779bdf4
)
name=scope                       # its tailnet name; hq looks for this one
base=/opt/scope-bridge
confdir=/etc/scope-bridge
conf=$confdir/mediamtx.yml
unit=/etc/systemd/system/scope-bridge.service
user=scope
port=8554                        # RTSP, for hq's relay

if [[ "${1:-}" == --undo ]]; then
  head1 "Removing the telescope relay"
  systemctl disable --now scope-bridge.service >/dev/null 2>&1 || true
  rm -f "$unit"; systemctl daemon-reload
  rm -rf "$base" "$confdir"
  if id "$user" >/dev/null 2>&1; then userdel "$user"; fi
  ok "removed the relay, $base, $confdir and the '$user' account"
  say "  Tailscale stays. To take this box off your tailnet too: sudo tailscale logout"
  exit 0
fi
rtsp=""
if [[ "${1:-}" == --rtsp ]]; then rtsp="${2:-}"; shift 2 || true; fi
[[ -z "${1:-}" ]] || die "usage: sudo bash $0  [--rtsp 'rtsp://…']   or   sudo bash $0 --undo"

case "$(uname -m)" in
  x86_64) arch=amd64 ;;
  aarch64|arm64) arch=arm64 ;;
  armv7l) arch=armv7 ;;
  armv6l) arch=armv6 ;;
  *) die "unsupported CPU: $(uname -m)" ;;
esac
have curl || die "curl is missing: sudo apt install -y curl"
have systemctl || die "this needs a Linux with systemd (Raspberry Pi OS, Ubuntu, Debian)"

head1 "Tailscale"
if have tailscale; then
  ok "already installed: $(tailscale version | head -1)"
else
  curl -fsSL https://tailscale.com/install.sh | sh
  ok "installed: $(tailscale version | head -1)"
fi
systemctl enable --now tailscaled >/dev/null 2>&1 || true
if tailscale status --peers=false >/dev/null 2>&1; then
  tailscale set --ssh --hostname="$name"
  ok "already on your tailnet; SSH on, name set to $name"
else
  say "  A login link will appear. Open it and sign in with the SAME account as your"
  say "  servers and phone."
  tailscale up --ssh --hostname="$name"
fi
tailscale set --auto-update >/dev/null 2>&1 || true
ts_ip="$(tailscale ip -4 | head -1)"
[[ "$ts_ip" =~ ^100\. ]] || die "no Tailscale address yet. Run this again in a minute."
ok "tailnet address $ts_ip"

head1 "The telescope's address"
old=""
[[ -f "$conf" ]] && old="$(sed -nE "s/^    source: '(.*)'$/\1/p" "$conf" | sed "s/''/'/g")"
if [[ -z "$rtsp" ]]; then
  [[ -r /dev/tty ]] || die "no address given: sudo bash $0 --rtsp 'rtsp://…'"
  say "  In the Seestar app: Settings → Advanced Feature → RTSP Address → Get."
  say "  Copy it and paste it here, then press Enter.${old:+ Just Enter keeps the one set now.}"
  read -r -p "  RTSP address: " rtsp </dev/tty || rtsp=""
fi
rtsp="$(printf '%s' "$rtsp" | tr -d '[:space:]')"
[[ -n "$rtsp" ]] || rtsp="$old"
[[ "$rtsp" =~ ^rtsps?://[^[:space:]]+$ ]] || die "that doesn't look like an RTSP address (it starts with rtsp://)"
ok "telescope at ${rtsp%%\?*}"

head1 "Relay (MediaMTX $MTX_VERSION)"
if ! id "$user" >/dev/null 2>&1; then
  useradd --system --no-create-home --home-dir /nonexistent --shell /usr/sbin/nologin "$user"
fi
if [[ "$("$base/mediamtx" --version 2>/dev/null || true)" != "$MTX_VERSION" ]]; then
  tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
  tarball="mediamtx_${MTX_VERSION}_linux_${arch}.tar.gz"
  curl -fsSL -o "$tmp/$tarball" "https://github.com/bluenviron/mediamtx/releases/download/$MTX_VERSION/$tarball"
  echo "${MTX_SHA256[$arch]}  $tmp/$tarball" | sha256sum -c --quiet - || die "the download's checksum is wrong. Nothing changed."
  tar -xzf "$tmp/$tarball" -C "$tmp" mediamtx LICENSE
  install -d -m 755 -o root -g root "$base"
  install -m 755 -o root -g root "$tmp/mediamtx" "$base/mediamtx"
  install -m 644 -o root -g root "$tmp/LICENSE" "$base/LICENSE"
fi
ok "$("$base/mediamtx" --version) in $base (checksum verified)"

install -d -m 750 -o root -g "$user" "$confdir"
yaml_rtsp="${rtsp//\'/\'\'}"
cat >"$conf.new" <<EOF
# Written by scripts/install-scope-bridge.sh; re-run it to change anything.
logLevel: warn
logDestinations: [stdout]
# Only video, only for reading, only from the tailnet. No publishing, no API.
authMethod: internal
authInternalUsers:
  - user: any
    pass:
    ips: ['100.64.0.0/10', 'fd7a:115c:a1e0::/48']
    permissions:
      - action: read
        path: seestar
api: false
metrics: false
pprof: false
playback: false
rtsp: true
rtspTransports: [tcp]
rtspEncryption: "no"
rtspAddress: '$ts_ip:$port'
rtmp: false
hls: false
webrtc: false
srt: false
moq: false
paths:
  seestar:
    source: '$yaml_rtsp'
    # Only pull from the telescope while hq's relay asks for it.
    sourceOnDemand: true
    sourceOnDemandStartTimeout: 15s
    sourceOnDemandCloseAfter: 30s
EOF
chown root:"$user" "$conf.new"; chmod 640 "$conf.new"; mv "$conf.new" "$conf"
ok "settings in $conf"

{
  echo "[Unit]"
  echo "Description=Telescope relay: Seestar live video for God's Eye View, over Tailscale only"
  echo "After=network-online.target tailscaled.service"
  echo "Wants=network-online.target"
  echo
  echo "[Service]"
  echo "User=$user"
  echo "Group=$user"
  echo "ExecStart=$base/mediamtx $conf"
  # Restarts until the Tailscale address is up after a reboot.
  echo "Restart=always"
  echo "RestartSec=5"
  echo "MemoryMax=300M"
  echo "NoNewPrivileges=yes"
  echo "ProtectSystem=strict"
  echo "ProtectHome=yes"
  echo "PrivateTmp=yes"
  echo "PrivateDevices=yes"
  echo
  echo "[Install]"
  echo "WantedBy=multi-user.target"
} >"$unit"
systemctl daemon-reload
systemctl enable scope-bridge.service >/dev/null
systemctl restart scope-bridge.service
up() { timeout 2 bash -c "exec 3<>/dev/tcp/$ts_ip/$port" 2>/dev/null; }
for _ in $(seq 1 15); do up && break; sleep 1; done
up || die "the relay didn't start. See: journalctl -u scope-bridge.service -n 50"
ok "relay on $ts_ip:$port (tailnet only)"

head1 "Is the telescope streaming?"
# Ask for the video the way hq's relay will (an RTSP DESCRIBE), from this box's
# tailnet address. 200 means the telescope's stream came through.
answer="$(timeout 25 bash -c 'exec 3<>"/dev/tcp/$0/$1"
  printf "DESCRIBE rtsp://%s:%s/seestar RTSP/1.0\r\nCSeq: 1\r\nAccept: application/sdp\r\n\r\n" "$0" "$1" >&3
  head -1 <&3' "$ts_ip" "$port" 2>/dev/null || true)"
if [[ "$answer" == "RTSP/1.0 200"* ]]; then
  ok "yes: the relay got video from the telescope"
else
  warn "not right now. That's fine: turn the telescope on, open Solar System or"
  say "    Landscape mode in the Seestar app, and the live view starts by itself."
  dim "check the address again if it never works: sudo journalctl -u scope-bridge.service -n 30"
fi

say
say "  Done on this box. Members see the telescope in God's Eye View (the 🔭 button)"
say "  or at /scope, whenever it is streaming."
say
say "  hq's relay reaches this box as $name. If hq's installer says it can't, add the"
say "  telescope rules from policy/tailnet-policy.hujson in the Tailscale console."
say "  New hotspot or new address in the app? Run this again and paste the new one."
say
say "  Undo: sudo bash scripts/install-scope-bridge.sh --undo"
